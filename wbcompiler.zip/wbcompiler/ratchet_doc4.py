"""
Continuous Ratchet Runner for Document 4 (Assembly & Verification: Steps 9, 10, 11)
Stress tests P/E quarantine table, Checks A-J failure containment, completion footer integrity,
and paired admission duplicate detection.
"""

from __future__ import annotations
import sys
import time
import hashlib
import tempfile
from pathlib import Path
from datetime import datetime

from step9_assembly import apply_quarantine_decision, assemble_document_twin
from step10_verification import verify_twin, check_a_source_integrity, check_g_identity_numbering
from step11_admission import admit_pair, verify_admission_conditions

LOG_FILE = Path("ratchet_audit.log")

def log(msg: str):
    timestamp = datetime.now().isoformat()
    entry = f"[{timestamp}] [ASSEMBLY & VERIFICATION RATCHET] {msg}"
    print(entry, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def test_doc4_baseline() -> bool:
    """Rigorous baseline test suite for Steps 9, 10, 11."""
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)
        src_file = p / "verified.txt"
        src_file.write_text("Acme Corp\nBuilt 5 systems in 2022.", encoding="utf-8")
        chk = hashlib.sha256(src_file.read_bytes()).hexdigest()

        src_rec = {
            "uid": "K9L",
            "filename": "verified.txt",
            "extension": ".txt",
            "checksum": chk,
            "path": str(src_file),
            "extracted_text": "Acme Corp\nBuilt 5 systems in 2022."
        }
        twin = assemble_document_twin(
            source_record=src_rec,
            person_bundle={"overall_status": "FOUND"},
            employment_decls=[{"label": "Employer A", "unicode_citation": "¿", "employer": "Acme Corp"}],
            atomic_blurbs=[{"uid": "K9L-001", "content": "Built 5 systems in 2022.", "citation": "¿", "source_location": "body"}],
            non_blurb_bundles=[],
            media_manifest=[],
            twins_dir=p / "twins",
            quarantine_dir=p / "quarantine"
        )
        assert twin["completion_footer"] is None

        # Verify twin
        twin_path = p / "twins" / "K9L-000_twin.json"
        res = verify_twin("K9L", src_file, twin, twin_path, src_rec, [])
        assert all(r.passed for r in res)
        assert twin["completion_footer"] is not None

        # Admit pair
        admitted = {}
        adm_rec = admit_pair("K9L", src_rec, twin, admitted)
        assert adm_rec.status == "ADMITTED"

    return True


def run_doc4_ratchet_loop(iterations: int = 5, delay_seconds: float = 1.0):
    log("Initializing Continuous Ratchet Loop for Document 4 (Assembly & Verification)...")

    cycle = 1
    while cycle <= iterations:
        log(f"--- Cycle {cycle}/{iterations}: Stress-testing Document 4 invariants ---")

        # Weak Point 1: Check J Gatekeeper (Footer must NEVER be written if any Check A-I fails)
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            corrupt_file = p / "tampered.txt"
            corrupt_file.write_text("Tampered bytes", encoding="utf-8")
            bad_chk = "0000000000000000000000000000000000000000000000000000000000000000"

            bad_src_rec = {
                "uid": "BAD",
                "filename": "tampered.txt",
                "extension": ".txt",
                "checksum": bad_chk,
                "path": str(corrupt_file),
                "extracted_text": "Tampered bytes"
            }
            bad_twin = {
                "twin_id": "BAD-000",
                "source_uid": "BAD",
                "source_checksum": bad_chk,
                "atomic_blurbs": [{"uid": "BAD-001", "content": "Fake content"}],
                "employment_declarations": [],
                "non_blurb_bundles": [],
                "media_refs": [],
                "p_status": "FOUND",
                "e_status": "FOUND",
                "completion_footer": None
            }
            bad_twin_path = p / "BAD-000_twin.json"
            bad_twin_path.write_text("{}", encoding="utf-8")

            results = verify_twin("BAD", corrupt_file, bad_twin, bad_twin_path, bad_src_rec, [])
            check_j = [r for r in results if r.check_id == "J"][0]
            assert check_j.passed is False, "Check J must fail when Check A fails!"
            assert bad_twin["completion_footer"] is None, "Footer must not be written on failure!"
        log("  [AUDIT] Weak-link probe: Gatekeeper Check J strictly blocks certification on Check A-I failure.")

        # Baseline Verification Gate
        baseline_ok = test_doc4_baseline()
        if baseline_ok:
            log("  [VERIFIED] All Document 4 invariants intact. Baseline locked.")
        else:
            log("  [ROLLBACK ALERT] Verification failed!")
            break

        time.sleep(delay_seconds)
        cycle += 1

    log("Document 4 Ratchet loop iteration batch completed successfully.")


if __name__ == "__main__":
    run_doc4_ratchet_loop(iterations=5, delay_seconds=1.0)
