"""
Command Line Interface (CLI) for Document & Statement Analysis Engine
Enables headless, deterministic document batch processing and piping.
"""

from __future__ import annotations
import sys
import json
import argparse
from pathlib import Path
from core_engine import process_resume, format_report_text


def main():
    parser = argparse.ArgumentParser(description="Deterministic Document & Statement Compiler CLI")
    parser.add_argument("input_file", nargs="?", help="Path to input text file (or read from stdin if omitted)")
    parser.add_argument("--json", action="store_true", help="Output results in JSON format")
    parser.add_argument("-o", "--output", help="Save output to a specific file")

    args = parser.parse_args()

    if args.input_file:
        input_path = Path(args.input_file)
        if not input_path.exists():
            print(f"Error: File not found: {args.input_file}", file=sys.stderr)
            sys.exit(1)
        raw_text = input_path.read_text(encoding="utf-8", errors="replace")
    else:
        if sys.stdin.isatty():
            print("Deterministic Document Engine: Enter text (Ctrl+Z or Ctrl+D to submit):")
        raw_text = sys.stdin.read()

    results = process_resume(raw_text)

    if args.json:
        output_content = json.dumps(results, indent=2)
    else:
        output_content = format_report_text(results)

    if args.output:
        Path(args.output).write_text(output_content, encoding="utf-8")
        print(f"Results saved to {args.output}")
    else:
        print(output_content)


if __name__ == "__main__":
    main()
