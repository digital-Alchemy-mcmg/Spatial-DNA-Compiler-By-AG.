"""
SDNA Evidence Foundry — Step 10: Independent Verification (Checks A–J)
Validates each Atomic Twin against its original source document.
Check J (Completion Footer) is written ONLY when Checks A through I all pass.
"""

from __future__ import annotations
import re
import json
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional

from docx import Document as DocxDocument
from pypdf import PdfReader

from step1_contracts import (
    ValidationResult,
    CompletionFooter,
    ProcessingStatus
)


def sha256_file(filepath: Path) -> str:
    """Compute SHA-256 hex digest of file bytes."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ── CHECK A: Source Integrity ──────────────────────────────────────────────
def check_a_source_integrity(source_uid: str, source_path: Path, registered_checksum: str) -> ValidationResult:
    """Re-reads original file bytes; verifies SHA-256 against registry."""
    if not source_path.exists():
        return ValidationResult(
            source_uid=source_uid, check_id="A", passed=False,
            observed="File not found on disk", expected=registered_checksum,
            failure_reason="Source file missing from disk"
        )
    computed = sha256_file(source_path)
    passed = (computed == registered_checksum)
    return ValidationResult(
        source_uid=source_uid, check_id="A", passed=passed,
        observed=computed, expected=registered_checksum,
        failure_reason=None if passed else "SHA-256 mismatch: source bytes altered"
    )


# ── CHECK B: Extraction Fidelity ──────────────────────────────────────────
def check_b_extraction_fidelity(
    source_uid: str,
    source_path: Path,
    extracted_text: str,
    source_format: str
) -> ValidationResult:
    """
    Independently re-reads source using the format library and verifies numbers
    and named entities in extracted text are present in the re-read source.
    """
    re_extracted = ""
    try:
        fmt = source_format.lower()
        if fmt == ".docx":
            doc = DocxDocument(str(source_path))
            re_extracted = " ".join(p.text for p in doc.paragraphs if p.text.strip())
        elif fmt == ".pdf":
            reader = PdfReader(str(source_path))
            re_extracted = " ".join(page.extract_text() or "" for page in reader.pages)
        elif fmt in (".txt", ".md"):
            re_extracted = source_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return ValidationResult(
            source_uid=source_uid, check_id="B", passed=False,
            observed=f"Re-extraction error: {e}", expected="Successful re-extraction",
            failure_reason=str(e)
        )

    nums_in_extraction = set(re.findall(r'\b\d+[%$.,]?\d*\b', extracted_text))
    nums_in_source = set(re.findall(r'\b\d+[%$.,]?\d*\b', re_extracted))
    unsupported = nums_in_extraction - nums_in_source
    passed = (len(unsupported) == 0)

    return ValidationResult(
        source_uid=source_uid, check_id="B", passed=passed,
        observed=f"Unsupported values: {unsupported}" if unsupported else "All values present in source",
        expected="All extracted values present in original source",
        failure_reason=None if passed else f"Values not found in source: {unsupported}"
    )


# ── CHECK C: Discovery Coverage ───────────────────────────────────────────
def check_c_discovery_coverage(source_uid: str, twin: Dict[str, Any]) -> ValidationResult:
    """Confirms both P and E discovery recorded explicit statuses in {FOUND, NOT_FOUND, AMBIGUOUS}."""
    valid_states = {"FOUND", "NOT_FOUND", "AMBIGUOUS"}
    p_st = twin.get("p_status", "")
    e_st = twin.get("e_status", "")
    passed = (p_st in valid_states and e_st in valid_states)
    return ValidationResult(
        source_uid=source_uid, check_id="C", passed=passed,
        observed=f"p_status={p_st}, e_status={e_st}",
        expected="Both statuses in {FOUND, NOT_FOUND, AMBIGUOUS}",
        failure_reason=None if passed else "Missing or invalid P/E discovery status"
    )


# ── CHECK D: Region Eligibility (SDNA-HF-001) ─────────────────────────────
def check_d_region_eligibility(
    source_uid: str,
    atomic_blurbs: List[Dict[str, Any]],
    non_blurb_bundles: List[Dict[str, Any]]
) -> ValidationResult:
    """Verifies no non-contact header/footer material was admitted as atomic blurbs or non-blurb info."""
    violations = []
    for b in atomic_blurbs:
        loc = b.get("source_location", "")
        if "header" in loc.lower() or "footer" in loc.lower():
            if b.get("content_type") != "contact":
                violations.append(f"Atom {b.get('uid')} from header/footer")

    for nb in non_blurb_bundles:
        loc = nb.get("source_location", "")
        if "header" in loc.lower() or "footer" in loc.lower():
            violations.append(f"NonBlurb {nb.get('bundle_type')} from header/footer")

    passed = (len(violations) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="D", passed=passed,
        observed=str(violations) if violations else "No header/footer violations",
        expected="Zero non-contact header/footer content admitted",
        failure_reason=None if passed else f"Violations detected: {violations}"
    )


# ── CHECK E: Atomic Content Fidelity ──────────────────────────────────────
def check_e_atomic_content_fidelity(
    source_uid: str,
    atomic_blurbs: List[Dict[str, Any]],
    source_text: str
) -> ValidationResult:
    """Verifies every numeric value and key fact in each blurb is present in original source text."""
    failures = []
    for blurb in atomic_blurbs:
        content = blurb.get("content", "")
        nums = set(re.findall(r'\b\d+[%$.,]?\d*\b', content))
        for n in nums:
            if n not in source_text:
                failures.append(f"Atom {blurb.get('uid')}: value {n!r} not in source")

    passed = (len(failures) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="E", passed=passed,
        observed=str(failures) if failures else "All atomic facts source-supported",
        expected="Every atomic fact present in source text",
        failure_reason=None if passed else "; ".join(failures)
    )


# ── CHECK F: Citation Integrity ───────────────────────────────────────────
def check_f_citation_integrity(
    source_uid: str,
    atomic_blurbs: List[Dict[str, Any]],
    employment_decls: List[Dict[str, Any]]
) -> ValidationResult:
    """Verifies every citation resolves to exactly one declaration in this twin."""
    declared = {d["unicode_citation"] for d in employment_decls if "unicode_citation" in d}
    failures = []
    for blurb in atomic_blurbs:
        cit = blurb.get("citation")
        if cit and cit not in declared:
            failures.append(f"Atom {blurb.get('uid')}: citation {cit!r} undeclared in twin")

    passed = (len(failures) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="F", passed=passed,
        observed=str(failures) if failures else "All citations resolve locally",
        expected="All citations match declarations in this twin",
        failure_reason=None if passed else "; ".join(failures)
    )


# ── CHECK G: Identity & Numbering ─────────────────────────────────────────
def check_g_identity_numbering(source_uid: str, twin: Dict[str, Any]) -> ValidationResult:
    """Verifies UID structure: source 3-char, twin UID+'-000', atoms sequential from -001."""
    failures = []
    twin_id = twin.get("twin_id", "")
    if twin_id != f"{source_uid}-000":
        failures.append(f"twin_id {twin_id!r} != expected {source_uid + '-000'!r}")

    atom_uids = [b["uid"] for b in twin.get("atomic_blurbs", [])]
    if len(atom_uids) != len(set(atom_uids)):
        failures.append("Duplicate atom UIDs detected in twin")

    for idx, uid in enumerate(atom_uids, start=1):
        expected = f"{source_uid}-{idx:03d}"
        if uid != expected:
            failures.append(f"Atom #{idx} UID={uid!r}, expected {expected!r}")
            break

    passed = (len(failures) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="G", passed=passed,
        observed=str(failures) if failures else "UID hierarchy and sequential numbering correct",
        expected=f"twin={source_uid}-000, atoms={source_uid}-001, -002...",
        failure_reason=None if passed else "; ".join(failures)
    )


# ── CHECK H: Non-Blurb Separation ─────────────────────────────────────────
def check_h_non_blurb_separation(
    source_uid: str,
    non_blurb_bundles: List[Dict[str, Any]],
    atomic_blurbs: List[Dict[str, Any]]
) -> ValidationResult:
    """Verifies non-blurbs are labeled SELF_REPORTED, contain no atom UIDs, and are excluded from atom counts."""
    failures = []
    atom_uids = {b["uid"] for b in atomic_blurbs}
    for bundle in non_blurb_bundles:
        if bundle.get("classification") != "SELF_REPORTED":
            failures.append(f"Bundle {bundle.get('bundle_type')} missing SELF_REPORTED")
        if "uid" in bundle and bundle["uid"] in atom_uids:
            failures.append(f"Non-blurb bundle assigned atom UID: {bundle['uid']}")

    passed = (len(failures) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="H", passed=passed,
        observed=str(failures) if failures else "Non-blurb bundles correctly separated and classified",
        expected="All bundles marked SELF_REPORTED, no atom UIDs assigned",
        failure_reason=None if passed else "; ".join(failures)
    )


# ── CHECK I: Media Inventory ──────────────────────────────────────────────
def check_i_media_inventory(
    source_uid: str,
    media_manifest: List[Dict[str, Any]],
    twin_media_refs: List[str]
) -> ValidationResult:
    """Verifies all twin media references exist in manifest with REGISTERED and PENDING_USER statuses."""
    failures = []
    manifest_map = {m["media_id"]: m for m in media_manifest}
    for ref in twin_media_refs:
        if ref not in manifest_map:
            failures.append(f"Media reference {ref!r} not found in manifest")
            continue
        entry = manifest_map[ref]
        if entry.get("registration_status") != ProcessingStatus.REGISTERED.value and entry.get("registration_status") != "REGISTERED":
            failures.append(f"Media {ref}: registration_status != REGISTERED")
        if entry.get("annotation_status") != ProcessingStatus.PENDING_USER.value and entry.get("annotation_status") != "PENDING_USER":
            failures.append(f"Media {ref}: annotation_status != PENDING_USER")

    passed = (len(failures) == 0)
    return ValidationResult(
        source_uid=source_uid, check_id="I", passed=passed,
        observed=str(failures) if failures else "All referenced media entries valid",
        expected="All media references REGISTERED + PENDING_USER",
        failure_reason=None if passed else "; ".join(failures)
    )


# ── CHECK J: Completion Footer ────────────────────────────────────────────
def check_j_write_completion_footer(
    source_uid: str,
    twin: Dict[str, Any],
    twin_path: Path,
    prior_checks: List[ValidationResult],
    media_manifest: List[Dict[str, Any]]
) -> ValidationResult:
    """Writes CompletionFooter ONLY if Checks A-I all passed."""
    prior_failures = [r for r in prior_checks if not r.passed]
    if prior_failures:
        return ValidationResult(
            source_uid=source_uid, check_id="J", passed=False,
            observed=f"{len(prior_failures)} prior check(s) failed",
            expected="All checks A-I must pass before completion footer is written",
            failure_reason=f"Failed prior checks: {[r.check_id for r in prior_failures]}"
        )

    blurbs = twin.get("atomic_blurbs", [])
    emp = twin.get("employment_declarations", [])
    media = twin.get("media_refs", [])

    pending_count = sum(
        1 for m in media_manifest
        if m.get("annotation_status") in ("PENDING_USER", ProcessingStatus.PENDING_USER.value)
    )

    atom_count = len(blurbs)
    last_uid = blurbs[-1]["uid"] if blurbs else f"{source_uid}-000"

    twin_json = json.dumps(twin, sort_keys=True)
    content_chk = hashlib.sha256(twin_json.encode("utf-8")).hexdigest()

    footer = CompletionFooter(
        source_uid=source_uid,
        twin_id=twin["twin_id"],
        atom_count=atom_count,
        last_atom_uid=last_uid,
        employment_count=len(emp),
        media_count=len(media),
        pending_annotations=pending_count,
        status=ProcessingStatus.COMPLETE,
        content_checksum=content_chk
    )

    twin["completion_footer"] = footer.model_dump()
    if twin_path.exists():
        with open(twin_path, "w", encoding="utf-8") as f:
            json.dump(twin, f, indent=2)

    return ValidationResult(
        source_uid=source_uid, check_id="J", passed=True,
        observed=f"Completion footer certified and written ({atom_count} atoms, {len(emp)} declarations)",
        expected="Completion footer written after Checks A-I pass"
    )


# ── Master Verification Orchestrator ──────────────────────────────────────
def verify_twin(
    source_uid: str,
    source_path: Path,
    twin: Dict[str, Any],
    twin_path: Path,
    source_record: Dict[str, Any],
    media_manifest: List[Dict[str, Any]]
) -> List[ValidationResult]:
    """Runs all 10 independent verification checks for a single Document Twin."""
    results = []
    blurbs = twin.get("atomic_blurbs", [])
    bundles = twin.get("non_blurb_bundles", [])
    emp = twin.get("employment_declarations", [])
    src_fmt = source_record.get("extension", "")
    src_text = source_record.get("extracted_text", "")

    results.append(check_a_source_integrity(source_uid, source_path, source_record["checksum"]))
    results.append(check_b_extraction_fidelity(source_uid, source_path, src_text, src_fmt))
    results.append(check_c_discovery_coverage(source_uid, twin))
    results.append(check_d_region_eligibility(source_uid, blurbs, bundles))
    results.append(check_e_atomic_content_fidelity(source_uid, blurbs, src_text))
    results.append(check_f_citation_integrity(source_uid, blurbs, emp))
    results.append(check_g_identity_numbering(source_uid, twin))
    results.append(check_h_non_blurb_separation(source_uid, bundles, blurbs))
    results.append(check_i_media_inventory(source_uid, media_manifest, twin.get("media_refs", [])))
    
    # Check J evaluated last
    results.append(check_j_write_completion_footer(source_uid, twin, twin_path, results, media_manifest))

    # Persist validation results
    vr_path = twin_path.parent / f"{source_uid}_validation.json"
    with open(vr_path, "w", encoding="utf-8") as f:
        json.dump([r.model_dump() for r in results], f, indent=2)

    return results


def verify_all_twins(
    twin_registry: Dict[str, Dict[str, Any]],
    source_registry: Dict[str, Dict[str, Any]],
    twins_dir: str | Path,
    media_manifest: List[Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """Verify all non-quarantined twins in the registry."""
    twins_path = Path(twins_dir)
    all_results = {}

    for uid, twin in twin_registry.items():
        if twin.get("is_quarantined"):
            continue
        twin_path = twins_path / f"{uid}-000_twin.json"
        src_rec = source_registry[uid]
        source_path = Path(src_rec["path"])
        res = verify_twin(uid, source_path, twin, twin_path, src_rec, media_manifest)
        all_results[uid] = [r.model_dump() for r in res]

    return all_results
