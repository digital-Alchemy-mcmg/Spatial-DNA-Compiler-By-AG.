"""
SDNA Evidence Foundry — Step 13: SDNA Package Assembly & Final Integrity Check
Builds the portable, self-contained ZIP archive ({Person_Name}_sDNA.zip),
runs the 8-point final integrity sweep, and generates package_inventory.json.
"""

from __future__ import annotations
import json
import zipfile
import hashlib
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple


def sha256_bytes(data: bytes) -> str:
    """Compute SHA-256 of raw bytes."""
    return hashlib.sha256(data).hexdigest()


def sha256_file(filepath: Path) -> str:
    """Compute SHA-256 of a disk file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def run_final_integrity_sweep(
    twin_registry: Dict[str, Dict[str, Any]],
    source_registry: Dict[str, Dict[str, Any]],
    admitted_registry: Dict[str, Dict[str, Any]],
    media_manifest: List[Dict[str, Any]],
    workbook_path: Path
) -> Tuple[bool, List[str]]:
    """
    Executes the 8-point final integrity sweep across all package references.
    Returns (passed: bool, failure_log: List[str]).
    """
    failures = []

    # 1. Atom -> Twin: Every atom UID resolves to its parent twin
    for uid, twin in twin_registry.items():
        if twin.get("is_quarantined"):
            continue
        atom_uids = [b["uid"] for b in twin.get("atomic_blurbs", [])]
        for a_uid in atom_uids:
            if not a_uid.startswith(f"{uid}-"):
                failures.append(f"Atom UID {a_uid} does not match parent twin UID {uid}")

    # 2. Twin -> Source: Every twin's source_uid maps to a source file
    for uid, twin in twin_registry.items():
        if uid not in source_registry:
            failures.append(f"Twin {twin.get('twin_id')} maps to unregistered source {uid}")
        else:
            src_path = Path(source_registry[uid]["path"])
            if not src_path.exists():
                failures.append(f"Source file for twin {uid} missing from disk: {src_path}")

    # 3. Source Checksum: Verify bytes on disk match registered SHA-256
    for uid, src_rec in source_registry.items():
        src_path = Path(src_rec["path"])
        if src_path.exists():
            computed = sha256_file(src_path)
            if computed != src_rec["checksum"]:
                failures.append(f"Source {uid} checksum corrupted on disk: expected {src_rec['checksum']}, got {computed}")

    # 4. Media References: Every twin media_ref resolves or is PENDING_USER
    manifest_ids = {m["media_id"] for m in media_manifest}
    for uid, twin in twin_registry.items():
        for m_ref in twin.get("media_refs", []):
            if m_ref not in manifest_ids:
                failures.append(f"Twin {uid} references unmanifested media {m_ref}")

    # 5. Workbook Provenance: Check that workbook exists and has size
    if not workbook_path.exists() or workbook_path.stat().st_size == 0:
        failures.append(f"Evidence workbook is missing or empty: {workbook_path}")

    # 6. Quarantine Records: Every quarantined twin has a quarantine reason
    for uid, twin in twin_registry.items():
        if twin.get("is_quarantined") and not twin.get("quarantine_reason"):
            failures.append(f"Quarantined twin {uid} missing quarantine reason")

    # 7. Sequential UIDs: Atom UIDs are contiguous from -001
    for uid, twin in twin_registry.items():
        if twin.get("is_quarantined"):
            continue
        for idx, blurb in enumerate(twin.get("atomic_blurbs", []), start=1):
            expected = f"{uid}-{idx:03d}"
            if blurb.get("uid") != expected:
                failures.append(f"Gap or mis-numbering in atom UIDs for twin {uid}: observed {blurb.get('uid')}, expected {expected}")
                break

    # 8. Paired Admission: Admitted twins must have matching admitted records
    for uid, adm_record in admitted_registry.items():
        if adm_record.get("status") == "ADMITTED":
            if uid not in twin_registry:
                failures.append(f"Admitted UID {uid} missing from twin registry")

    passed = (len(failures) == 0)
    return passed, failures


def assemble_sdna_package(
    person_name: str,
    twin_registry: Dict[str, Dict[str, Any]],
    source_registry: Dict[str, Dict[str, Any]],
    admitted_registry: Dict[str, Dict[str, Any]],
    media_manifest: List[Dict[str, Any]],
    workbook_path: Path,
    twins_dir: Path,
    quarantine_dir: Path,
    output_dir: str | Path = "outputs"
) -> Path:
    """
    Runs the final integrity sweep and packages all evidence into {Person_Name}_sDNA.zip.
    Throws RuntimeError if the integrity sweep detects any broken provenance links.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 1. Run Final Integrity Sweep
    sweep_passed, sweep_failures = run_final_integrity_sweep(
        twin_registry, source_registry, admitted_registry, media_manifest, workbook_path
    )
    if not sweep_passed:
        error_msg = f"Final integrity sweep failed ({len(sweep_failures)} errors):\n" + "\n".join(sweep_failures)
        logging.error(error_msg)
        raise RuntimeError(error_msg)

    # 2. Prepare Package Archive
    sanitized_name = person_name.strip().replace(" ", "_") or "Candidate"
    zip_filename = f"{sanitized_name}_sDNA.zip"
    zip_path = out_path / zip_filename

    inventory = {
        "person_name": person_name,
        "package_filename": zip_filename,
        "files": []
    }

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        # A. Write workbook
        if workbook_path.exists():
            arcname = "evidence_workbook.xlsx"
            zf.write(workbook_path, arcname=arcname)
            inventory["files"].append({
                "path": arcname,
                "checksum": sha256_file(workbook_path),
                "type": "workbook"
            })

        # B. Write sources/
        for uid, s_rec in source_registry.items():
            s_file = Path(s_rec["path"])
            if s_file.exists():
                arcname = f"sources/{s_file.name}"
                zf.write(s_file, arcname=arcname)
                inventory["files"].append({
                    "path": arcname,
                    "checksum": sha256_file(s_file),
                    "type": "source"
                })

        # C. Write atomic_twins/
        for uid, twin in twin_registry.items():
            if not twin.get("is_quarantined"):
                t_bytes = json.dumps(twin, indent=2).encode("utf-8")
                arcname = f"atomic_twins/{uid}-000_twin.json"
                zf.writestr(arcname, t_bytes)
                inventory["files"].append({
                    "path": arcname,
                    "checksum": sha256_bytes(t_bytes),
                    "type": "twin"
                })

        # D. Write Quarantined/
        for uid, twin in twin_registry.items():
            if twin.get("is_quarantined"):
                q_bytes = json.dumps(twin, indent=2).encode("utf-8")
                arcname = f"Quarantined/{uid}-000_quarantine_twin.json"
                zf.writestr(arcname, q_bytes)
                inventory["files"].append({
                    "path": arcname,
                    "checksum": sha256_bytes(q_bytes),
                    "type": "quarantine_manifest"
                })

        # E. Write media manifest & admission registry JSON
        med_bytes = json.dumps(media_manifest, indent=2).encode("utf-8")
        zf.writestr("media_manifest.json", med_bytes)
        inventory["files"].append({"path": "media_manifest.json", "checksum": sha256_bytes(med_bytes), "type": "registry"})

        adm_bytes = json.dumps(list(admitted_registry.values()), indent=2).encode("utf-8")
        zf.writestr("admission_registry.json", adm_bytes)
        inventory["files"].append({"path": "admission_registry.json", "checksum": sha256_bytes(adm_bytes), "type": "registry"})

        # F. Write package inventory into root of archive
        inv_bytes = json.dumps(inventory, indent=2).encode("utf-8")
        zf.writestr("package_inventory.json", inv_bytes)

    # Compute package-level checksum
    package_checksum = sha256_file(zip_path)
    logging.info(f"SDNA Package sealed: {zip_path} (SHA-256: {package_checksum})")

    return zip_path
