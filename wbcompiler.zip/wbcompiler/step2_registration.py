"""
SDNA Evidence Foundry — Step 2: Source File Discovery & Registration
Provides immutable intake, hashing, classification, and UID assignment.
"""

from __future__ import annotations
import hashlib
import json
import random
import shutil
import string
from pathlib import Path
from typing import Dict, Any, List, Set

from step1_contracts import (
    ACCEPTED_FORMATS,
    ACCEPTED_MEDIA,
    UNSUPPORTED_FORMATS,
    SourceRecord,
    ProcessingStatus
)


def generate_uid(existing_uids: Set[str]) -> str:
    """Generate a unique 3-character uppercase alphanumeric UID."""
    chars = string.ascii_uppercase + string.digits
    while True:
        uid = ''.join(random.choices(chars, k=3))
        if uid not in existing_uids:
            existing_uids.add(uid)
            return uid


def compute_checksum(filepath: Path) -> str:
    """Compute SHA-256 checksum of raw file bytes."""
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def classify_file(filepath: Path) -> str:
    """Classify file as 'document', 'media', or 'unsupported'."""
    ext = filepath.suffix.lower()
    if ext in ACCEPTED_FORMATS:
        return "document"
    for category, extensions in ACCEPTED_MEDIA.items():
        if ext in extensions:
            return "media"
    return "unsupported"


def discover_and_register(input_dir: str | Path, output_dir: str | Path = "sources") -> Dict[str, Any]:
    """
    Scan input directory, unpack any ZIP packages, classify files, assign UIDs,
    compute SHA-256 hashes, copy to immutable sources storage, and generate ground-truth registry.
    """
    import zipfile
    input_path = Path(input_dir)
    sources_path = Path(output_dir)
    sources_path.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    existing_uids: Set[str] = set()
    registry: Dict[str, Dict[str, Any]] = {}
    rejections: List[Dict[str, Any]] = []

    # 1. Expand any ZIP archives into a staging extraction area so their contents are registered individually
    staged_extracted_dir = sources_path / ".staged_archives"
    staged_extracted_dir.mkdir(parents=True, exist_ok=True)

    # Discover all candidate files, avoiding the output directory itself
    raw_files = [
        f for f in input_path.rglob("*")
        if f.is_file() and not str(f.resolve()).startswith(str(sources_path.resolve()))
    ]

    all_files: List[Path] = []
    for f in raw_files:
        if f.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(f, "r") as zf:
                    # Extract to an isolated subfolder per zip
                    zip_extract_target = staged_extracted_dir / f.stem
                    zip_extract_target.mkdir(parents=True, exist_ok=True)
                    zf.extractall(zip_extract_target)
                    for extracted_file in zip_extract_target.rglob("*"):
                        if extracted_file.is_file():
                            all_files.append(extracted_file)
            except Exception as e:
                rejections.append({
                    "filename": f.name,
                    "extension": ".zip",
                    "reason": f"Corrupt or invalid zip archive: {str(e)}",
                    "action": "File rejected — not admitted to pipeline"
                })
        else:
            all_files.append(f)

    for filepath in sorted(all_files):
        ext = filepath.suffix.lower()
        format_class = classify_file(filepath)

        if format_class == "unsupported":
            rejections.append({
                "filename": filepath.name,
                "extension": ext,
                "reason": f"Format '{ext}' is not supported. Accepted: {list(ACCEPTED_FORMATS.keys())}",
                "action": "File rejected — not admitted to pipeline"
            })
            continue

        uid = generate_uid(existing_uids)
        checksum = compute_checksum(filepath)

        # Copy to sources directory (immutability boundary)
        dest = sources_path / f"{uid}_{filepath.name}"
        shutil.copy2(filepath, dest)

        record = SourceRecord(
            uid=uid,
            filename=filepath.name,
            extension=ext,
            checksum=checksum,
            format_class=format_class,
            path=str(dest.resolve()),
            status=ProcessingStatus.REGISTERED
        )
        registry[uid] = record.model_dump()

    # Persist registry
    registry_file = sources_path / "source_registry.json"
    with open(registry_file, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2)

    # Persist rejections
    rejections_file = sources_path / "rejection_receipts.json"
    if rejections:
        with open(rejections_file, "w", encoding="utf-8") as f:
            json.dump(rejections, f, indent=2)

    return {
        "registry": registry,
        "rejections": rejections,
        "registry_file": str(registry_file),
        "rejections_file": str(rejections_file) if rejections else None
    }
