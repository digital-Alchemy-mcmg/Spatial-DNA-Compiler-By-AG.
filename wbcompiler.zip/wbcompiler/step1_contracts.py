"""
SDNA Evidence Foundry — Step 1: Configuration, Constants & Pydantic Data Models
Authoritative shared contracts for all downstream steps.
"""

from __future__ import annotations
from typing import Optional, List, Dict
from enum import Enum
from pydantic import BaseModel, Field

# ── Accepted Document Formats ──────────────────────────────────
ACCEPTED_FORMATS = {
    ".docx": "Microsoft Word — python-docx extraction",
    ".txt":  "Plain text — charset-normalizer encoding detection",
    ".pdf":  "PDF — pypdf extraction (machine-readable only)",
    ".md":   "Markdown — markdown-it-py structural parsing",
}

# ── Accepted Media Types ───────────────────────────────────────
ACCEPTED_MEDIA = {
    "image": [".png", ".jpg", ".jpeg", ".tiff", ".webp"],
    "video": [".mp4"],
    "audio": [".mp3", ".wav", ".m4a"],
    "unreadable_pdf": [".pdf"],  # PDFs that fail text extraction
}

# ── Unsupported Formats (explicit rejection receipts) ──────────
UNSUPPORTED_FORMATS = [".csv", ".xls", ".xlsx"]

# ── Unicode Citation Pool ──────────────────────────────────────
UNICODE_CITATION_POOL = ["¿", "¡", "¶", "§", "‽", "⁂", "†", "‡", "⁊", "⁓"]

def get_citation_symbol(index: int) -> str:
    """Assign citation symbol by index. After pool exhaustion, double symbols."""
    pool_size = len(UNICODE_CITATION_POOL)
    if index < pool_size:
        return UNICODE_CITATION_POOL[index]
    overflow = index - pool_size
    first = UNICODE_CITATION_POOL[(overflow // pool_size) % pool_size]
    second = UNICODE_CITATION_POOL[overflow % pool_size]
    return first + second

# ── Enums ──────────────────────────────────────────────────────
class DiscoveryState(str, Enum):
    FOUND = "FOUND"
    NOT_FOUND = "NOT_FOUND"
    AMBIGUOUS = "AMBIGUOUS"

class ProcessingStatus(str, Enum):
    REGISTERED = "REGISTERED"
    PENDING_USER = "PENDING_USER"
    QUARANTINED = "QUARANTINED"
    PROCESSING = "PROCESSING"
    VALIDATED = "VALIDATED"
    COMPLETE = "COMPLETE"

# ── Pydantic Data Contracts ────────────────────────────────────
class SourceRecord(BaseModel):
    uid: str = Field(..., min_length=3, max_length=3, description="3-char alphanumeric UID")
    filename: str
    extension: str
    checksum: str = Field(..., description="SHA-256 hex digest")
    format_class: str = Field(..., description="'document', 'media', or 'unsupported'")
    path: str
    status: ProcessingStatus = ProcessingStatus.REGISTERED

class MediaManifestEntry(BaseModel):
    media_id: str
    filename: str
    file_type: str
    category: str  # image, video, audio, unreadable_pdf
    source_document: Optional[str] = None
    source_location: Optional[str] = None
    checksum: str
    registration_status: ProcessingStatus = ProcessingStatus.REGISTERED
    annotation_status: ProcessingStatus = ProcessingStatus.PENDING_USER
    # User annotation fields — blank until user fills them
    what_is_this: Optional[str] = None
    what_does_it_represent: Optional[str] = None
    what_does_it_demonstrate: Optional[str] = None
    associated_project: Optional[str] = None
    attribution_issuer: Optional[str] = None

class ContactElement(BaseModel):
    value: Optional[str] = None
    discovery_state: DiscoveryState = DiscoveryState.NOT_FOUND
    source_location: Optional[str] = None

class PersonBundle(BaseModel):
    name: ContactElement = ContactElement()
    email: ContactElement = ContactElement()
    phone: ContactElement = ContactElement()
    location: ContactElement = ContactElement()
    profile_links: List[ContactElement] = []
    overall_status: DiscoveryState = DiscoveryState.NOT_FOUND

class EmploymentDeclaration(BaseModel):
    label: str  # "Employer A", "Employer B", etc.
    unicode_citation: str  # ¿, ¡, ¶, etc.
    employer: Optional[str] = None
    position: Optional[str] = None
    dates: Optional[str] = None
    source_locations: List[str] = []
    discovery_state: DiscoveryState = DiscoveryState.FOUND

class AtomicBlurb(BaseModel):
    uid: str  # e.g., "A7B-001"
    content: str
    citation: Optional[str] = None
    employment_label: Optional[str] = None
    source_location: str
    is_cited: bool = False

class NonBlurbBundle(BaseModel):
    bundle_type: str
    content: str
    classification: str = "SELF_REPORTED"
    source_location: str

class CompletionFooter(BaseModel):
    source_uid: str
    twin_id: str
    atom_count: int
    last_atom_uid: str
    employment_count: int
    media_count: int
    pending_annotations: int
    status: ProcessingStatus
    content_checksum: str

class ValidationResult(BaseModel):
    source_uid: str
    check_id: str  # "A" through "J"
    passed: bool
    observed: str
    expected: str
    failure_reason: Optional[str] = None

class QuarantineRecord(BaseModel):
    source_uid: str
    reason: str
    discovery_results: Dict[str, str]
    processing_status: ProcessingStatus = ProcessingStatus.QUARANTINED

class DocumentTwin(BaseModel):
    twin_id: str  # "{source_uid}-000"
    source_uid: str
    source_checksum: str
    person_bundle: Optional[PersonBundle] = None
    employment_declarations: List[EmploymentDeclaration] = []
    atomic_blurbs: List[AtomicBlurb] = []
    non_blurb_info: List[NonBlurbBundle] = []
    media_refs: List[str] = []
    discovery_results: Dict[str, str] = {}
    completion_footer: Optional[CompletionFooter] = None
