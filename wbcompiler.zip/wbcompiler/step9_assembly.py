"""
SDNA Evidence Foundry — Step 9: Quarantine Decision & Document Twin Assembly
Evaluates the P/E quarantine decision table (SDNA-DP-003 §14), assembles DocumentTwin structures,
and withholds the completion footer until independent verification in Step 10.
"""

from __future__ import annotations
import json
import shutil
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional

from step1_contracts import (
    DiscoveryState,
    ProcessingStatus,
    QuarantineRecord
)


def apply_quarantine_decision(p_status: str, e_status: str) -> str:
    """
    Applies the P/E quarantine gate per SDNA-DP-003 §14.
    AMBIGUOUS is strictly treated as NOT_FOUND for both anchors.
    Returns: 'PROCESS', 'PROCESS_NO_E', 'PROCESS_NO_P', or 'QUARANTINE'.
    """
    p_confirmed = (p_status == DiscoveryState.FOUND.value or p_status == "FOUND")
    e_confirmed = (e_status == DiscoveryState.FOUND.value or e_status == "FOUND")

    if p_confirmed and e_confirmed:
        return "PROCESS"
    elif p_confirmed and not e_confirmed:
        return "PROCESS_NO_E"
    elif not p_confirmed and e_confirmed:
        return "PROCESS_NO_P"
    else:
        return "QUARANTINE"


def assemble_document_twin(
    source_record: Dict[str, Any],
    person_bundle: Dict[str, Any],
    employment_decls: List[Dict[str, Any]],
    atomic_blurbs: List[Dict[str, Any]],
    non_blurb_bundles: List[Dict[str, Any]],
    media_manifest: List[Dict[str, Any]],
    twins_dir: str | Path = "atomic_twins",
    quarantine_dir: str | Path = "quarantined"
) -> Dict[str, Any]:
    """
    Applies the quarantine decision and assembles the initial DocumentTwin.
    Completion footer is DELIBERATELY OMITTED here (written only after Step 10 checks pass).
    """
    twins_path = Path(twins_dir)
    quarantine_path = Path(quarantine_dir)

    uid = source_record["uid"]
    twin_id = f"{uid}-000"
    p_status = person_bundle.get("overall_status", person_bundle.get("p_status", "NOT_FOUND"))
    e_status = source_record.get("e_status", "NOT_FOUND")

    decision = apply_quarantine_decision(p_status, e_status)

    # 1. Quarantine Branch
    if decision == "QUARANTINE":
        quarantine_path.mkdir(parents=True, exist_ok=True)
        q_reason = "Neither P nor E anchor confirmed (AMBIGUOUS treated as NOT_FOUND)"
        
        # Original source copy moved to quarantined folder
        src_path = Path(source_record["path"])
        if src_path.exists():
            shutil.copy2(src_path, quarantine_path / src_path.name)

        twin = {
            "twin_id": twin_id,
            "source_uid": uid,
            "source_checksum": source_record["checksum"],
            "source_filename": source_record["filename"],
            "source_format": source_record.get("extension", ""),
            "p_status": p_status,
            "e_status": e_status,
            "employment_declarations": [],
            "atomic_blurbs": [],
            "non_blurb_bundles": [],
            "media_refs": [],
            "quarantine_reason": q_reason,
            "is_quarantined": True,
            "completion_footer": None
        }

        out_path = quarantine_path / f"{twin_id}_twin.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(twin, f, indent=2)

        return twin

    # 2. Process Branch (PROCESS, PROCESS_NO_E, or PROCESS_NO_P)
    twins_path.mkdir(parents=True, exist_ok=True)
    my_media = [
        m["media_id"] for m in media_manifest
        if m.get("source_document") == uid or m.get("media_id") == f"MED-{uid}"
    ]

    twin = {
        "twin_id": twin_id,
        "source_uid": uid,
        "source_checksum": source_record["checksum"],
        "source_filename": source_record["filename"],
        "source_format": source_record.get("extension", ""),
        "p_status": p_status,
        "e_status": e_status,
        "employment_declarations": employment_decls,
        "atomic_blurbs": atomic_blurbs,
        "non_blurb_bundles": non_blurb_bundles,
        "media_refs": my_media,
        "quarantine_reason": None,
        "is_quarantined": False,
        "completion_footer": None  # Gated behind Step 10
    }

    out_path = twins_path / f"{twin_id}_twin.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(twin, f, indent=2)

    return twin


def assemble_all_twins(
    source_registry: Dict[str, Dict[str, Any]],
    person_bundles: Dict[str, Dict[str, Any]],
    employment_map: Dict[str, Any],
    blurb_map: Dict[str, List[Dict[str, Any]]],
    non_blurb_map: Dict[str, List[Dict[str, Any]]],
    media_manifest: List[Dict[str, Any]],
    twins_dir: str | Path = "atomic_twins",
    quarantine_dir: str | Path = "quarantined"
) -> Dict[str, Dict[str, Any]]:
    """Assemble twins across all registered document sources."""
    twins_path = Path(twins_dir)
    twins_path.mkdir(parents=True, exist_ok=True)
    twin_registry = {}

    for uid, record in source_registry.items():
        if record.get("format_class") != "document":
            continue

        emp_entry = employment_map.get(uid, {})
        decls = emp_entry.get("declarations", []) if isinstance(emp_entry, dict) else []
        record_e_status = emp_entry.get("e_status", "NOT_FOUND") if isinstance(emp_entry, dict) else "NOT_FOUND"
        record["e_status"] = record_e_status

        twin = assemble_document_twin(
            source_record=record,
            person_bundle=person_bundles.get(uid, {}),
            employment_decls=decls,
            atomic_blurbs=blurb_map.get(uid, []),
            non_blurb_bundles=non_blurb_map.get(uid, []),
            media_manifest=media_manifest,
            twins_dir=twins_dir,
            quarantine_dir=quarantine_dir
        )
        twin_registry[uid] = twin

    with open(twins_path / "twin_registry.json", "w", encoding="utf-8") as f:
        json.dump(twin_registry, f, indent=2)

    return twin_registry
