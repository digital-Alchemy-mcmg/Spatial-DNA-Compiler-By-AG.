"""
SDNA Evidence Foundry — Step 6: Employment (E) Bundle Discovery & Declaration Anchoring
Identifies employer-position-date combinations, assigns alphabetical labels and Unicode citations.
Governed by SDNA-DP-003.
"""

from __future__ import annotations
import re
import string
import spacy
from typing import List, Dict, Any, Optional, Tuple

from step1_contracts import (
    DiscoveryState,
    EmploymentDeclaration,
    get_citation_symbol,
    UNICODE_CITATION_POOL
)

nlp = spacy.load("en_core_web_sm")

DATE_PATTERNS = [
    # 2018–2021 or 2018-2021
    r"\b(\d{4})\s*[–—\-]\s*(\d{4}|[Pp]resent|[Cc]urrent)\b",
    # Jan 2018 – Dec 2021 or January 2018 - Present
    r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
    r"Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
    r"\s+\d{4}\s*[–—\-]\s*(?:\w+\s+)?(?:\d{4}|[Pp]resent|[Cc]urrent)\b",
    # Standalone year (fallback)
    r"\b(\d{4})\b"
]

TITLE_KEYWORDS = [
    "Manager", "Director", "Engineer", "Analyst", "Coordinator",
    "Specialist", "Consultant", "Developer", "Designer", "Lead",
    "Officer", "Executive", "Vice President", "VP", "President",
    "Associate", "Senior", "Junior", "Head", "Chief", "Supervisor",
    "Administrator", "Architect", "Scientist", "Strategist"
]


def get_label(index: int) -> str:
    """Return 'Employer A', 'Employer B', ... 'Employer AA' for index 0, 1, 2..."""
    letters = string.ascii_uppercase
    if index < len(letters):
        return f"Employer {letters[index]}"
    i, j = divmod(index - len(letters), len(letters))
    return f"Employer {letters[i]}{letters[j]}"


def find_date_ranges(text: str) -> List[str]:
    """Extract date-range mentions from text, preferring full-range patterns."""
    found = []
    for pattern in DATE_PATTERNS[:2]:
        for match in re.finditer(pattern, text):
            span = match.group(0).strip()
            if span and span not in found:
                found.append(span)
    return found


# Common non-organization false positives from NER
NON_ORG_WORDS = {
    "devops", "skills", "technical skills", "summary", "profile", "career",
    "experience", "work experience", "education", "certifications", "objective",
    "languages", "tools", "competencies", "projects", "hobbies", "interests"
}

# Section titles that delineate employment history
EXPERIENCE_SECTION_HEADERS = [
    r"\b(?:work\s+experience|professional\s+experience|employment\s+history|experience|career\s+history)\b"
]

ANCILLARY_HEADERS_STOP = [
    r"\b(?:technical\s+skills|skills|education|certifications|career\s+objective|objective|summary|profile|interests)\b"
]


def isolate_experience_regions(body_text: str) -> str:
    """Isolate the work experience portion of the document body text."""
    lines = body_text.splitlines()
    in_exp = False
    exp_lines = []

    for line in lines:
        clean = line.strip()
        if not clean:
            continue
        # Check if line starts an experience section
        if any(re.search(pat, clean, re.IGNORECASE) for pat in EXPERIENCE_SECTION_HEADERS):
            in_exp = True
            continue
        # Check if line enters an ancillary section after experience
        if in_exp and any(re.search(pat, clean, re.IGNORECASE) for pat in ANCILLARY_HEADERS_STOP):
            in_exp = False
            break
        if in_exp:
            exp_lines.append(line)

    if exp_lines:
        return "\n".join(exp_lines)
    return body_text


def find_org_candidates(text: str) -> List[str]:
    """Propose employer candidates using spaCy NER and structural line heuristics."""
    candidates = []

    # 1. spaCy NER
    doc = nlp(text[:15000])
    for ent in doc.ents:
        if ent.label_ in ("ORG", "GPE"):
            t = ent.text.strip()
            if len(t) > 2 and t.lower() not in NON_ORG_WORDS and t not in candidates:
                if not any(c in t for c in [":", "|", "•", "–", "-"]):
                    candidates.append(t)

    # 2. Structural Line Heuristics: lines preceding position titles or dates
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for i, line in enumerate(lines):
        if any(re.search(rf"\b{re.escape(kw)}\b", line, re.IGNORECASE) for kw in TITLE_KEYWORDS):
            # The line above the title is often the Company name
            if i > 0:
                prev_line = lines[i - 1]
                if (2 < len(prev_line) < 60
                        and prev_line.lower() not in NON_ORG_WORDS
                        and not any(c in prev_line for c in ["•", "*", "|"])
                        and prev_line not in candidates):
                    candidates.append(prev_line)
        # Or company name followed by date range
        date_matches = find_date_ranges(line)
        if date_matches and len(line) < 80:
            cleaned_line = line
            for d in date_matches:
                cleaned_line = cleaned_line.replace(d, "")
            cleaned_line = cleaned_line.strip(" ,|–-")
            if (2 < len(cleaned_line) < 60
                    and cleaned_line.lower() not in NON_ORG_WORDS
                    and cleaned_line not in candidates):
                candidates.append(cleaned_line)

    return candidates


def find_position_candidates(text: str) -> List[str]:
    """Identify candidate job title lines using keyword heuristics."""
    candidates = []
    for line in text.splitlines():
        line = line.strip()
        if not line or len(line) > 120:
            continue
        if any(re.search(rf"\b{re.escape(kw)}\b", line, re.IGNORECASE) for kw in TITLE_KEYWORDS):
            if line not in candidates:
                candidates.append(line)
    return candidates


def extract_docx_structure_hints(docx_path: str) -> List[Dict[str, str]]:
    """Extract heading-style paragraphs and bold runs as structural hints."""
    from docx import Document as DocxDocument
    hints = []
    try:
        doc = DocxDocument(docx_path)
        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            if para.style and para.style.name.startswith("Heading"):
                hints.append({"type": "heading", "text": text, "style": para.style.name})
            elif any(run.bold for run in para.runs if run.text.strip()):
                hints.append({"type": "bold", "text": text})
    except Exception:
        pass
    return hints


def parse_delimiters_line(line: str) -> Optional[Dict[str, Optional[str]]]:
    """
    Parses a single line containing combinations of (Employer, Position, Dates)
    separated by common delimiters: '/', '|', or '—' / '-'.
    Supports any ordering convention per SDNA-DP-003.
    """
    clean_line = line.strip()
    if not clean_line or len(clean_line) > 120:
        return None

    # Check for date in parentheses at end: e.g. "Store Manager — Joanne's Fabrics (2018–2021)"
    paren_date = re.search(r"\(([^)]+)\)$", clean_line)
    detected_dates = None
    core_line = clean_line

    if paren_date:
        candidate_date = paren_date.group(1).strip()
        if any(re.search(pat, candidate_date) for pat in DATE_PATTERNS):
            detected_dates = candidate_date
            core_line = clean_line[:paren_date.start()].strip()

    # Split by standard delimiters
    delimiter_pattern = r"\s*[/|—–]\s*"
    parts = [p.strip() for p in re.split(delimiter_pattern, core_line) if p.strip()]

    if len(parts) >= 2 or (len(parts) >= 1 and detected_dates):
        employer = None
        position = None
        dates = detected_dates

        # Evaluate each part
        for part in parts:
            # 1. Date check first (strict check)
            if not dates:
                date_matches = find_date_ranges(part)
                # If the part is primarily a date range, capture it
                if date_matches and any(c.isdigit() for c in part) and len(part) < 35:
                    dates = date_matches[0]
                    continue
            # Also skip if part is purely dates
            if any(re.search(pat, part) for pat in DATE_PATTERNS[:2]) or (len(part) <= 15 and any(c.isdigit() for c in part) and not any(c.isalpha() for c in part)):
                continue

            # 2. Position check
            if not position and any(re.search(rf"\b{re.escape(kw)}\b", part, re.IGNORECASE) for kw in TITLE_KEYWORDS):
                position = part
                continue

            # 3. Employer candidate
            if not employer and part.lower() not in NON_ORG_WORDS and not any(c.isdigit() for c in part if len(part) < 10):
                employer = part

        # If 2 out of 3 elements identified, return valid bundle
        if sum(1 for v in [employer, position, dates] if v) >= 2:
            return {"employer": employer, "position": position, "dates": dates}

    return None


def assemble_employment_bundles(
    orgs: List[str],
    positions: List[str],
    dates: List[str],
    text: str,
    source_uid: str
) -> List[Dict[str, Any]]:
    """
    Groups org, position, and date candidates into bundles.
    First checks structured single-line delimiter patterns (SDNA-DP-003 ordering invariance).
    Then falls back to proximity window search across nearby candidates.
    """
    bundles = []
    seen_employers = set()

    # 1. Fast path: Line-by-line delimiter parser (handles Joanne's Fabrics ordering variations)
    for line in text.splitlines():
        parsed = parse_delimiters_line(line)
        if parsed and parsed["employer"]:
            emp_clean = parsed["employer"]
            if emp_clean.lower() not in seen_employers:
                seen_employers.add(emp_clean.lower())
                bundles.append({
                    "employer": emp_clean,
                    "position": parsed["position"],
                    "dates": parsed["dates"],
                    "source_location": f"{source_uid} — structured line: {line.strip()}"
                })

    # If structured lines already satisfied the discovery, return them
    if bundles:
        return bundles

    # 2. Proximity window fallback
    for org in orgs:
        org_clean = org.strip()
        if not org_clean or org_clean.lower() in seen_employers:
            continue
        org_pos = text.find(org_clean)
        if org_pos == -1:
            continue
        seen_employers.add(org_clean.lower())

        start = max(0, org_pos - 200)
        end = min(len(text), org_pos + 400)
        window = text[start:end]

        nearby_dates = find_date_ranges(window)
        nearby_pos = [p for p in positions if p.lower() in window.lower()]

        bundle = {
            "employer": org_clean,
            "position": nearby_pos[0] if nearby_pos else None,
            "dates": nearby_dates[0] if nearby_dates else None,
            "source_location": f"{source_uid} — char offset ~{org_pos}"
        }

        filled = sum(1 for v in [bundle["employer"], bundle["position"], bundle["dates"]] if v)
        if filled >= 2:
            bundles.append(bundle)

    return bundles


def discover_employment_bundles(extraction_record: Dict[str, Any]) -> Tuple[List[EmploymentDeclaration], DiscoveryState]:
    """Run full E-bundle discovery on a single extraction record."""
    source_uid = extraction_record.get("source_uid", "SRC")
    body_text = extraction_record.get("body_text", "")
    source_path = extraction_record.get("source_path", "")

    if not body_text.strip():
        return [], DiscoveryState.NOT_FOUND

    # Scope candidates to the work experience section if identifiable
    search_text = isolate_experience_regions(body_text)

    # 1. Propose employer candidates
    orgs = find_org_candidates(search_text)

    # 2. Extract dates
    dates = find_date_ranges(search_text)

    # 3. Extract position candidates
    positions = find_position_candidates(search_text)

    # 4. Format-assisted hints for DOCX
    if source_path and source_path.lower().endswith(".docx"):
        hints = extract_docx_structure_hints(source_path)
        for hint in hints:
            h_text = hint["text"]
            if h_text and h_text not in orgs and len(h_text) < 60:
                orgs.append(h_text)

    # 5. Assemble raw bundles
    raw_bundles = assemble_employment_bundles(orgs, positions, dates, body_text, source_uid)

    if not raw_bundles:
        if orgs or dates:
            return [], DiscoveryState.AMBIGUOUS
        return [], DiscoveryState.NOT_FOUND

    # 6. Build strongly-typed EmploymentDeclaration records
    declarations = []
    for idx, bundle in enumerate(raw_bundles):
        decl = EmploymentDeclaration(
            label=get_label(idx),
            unicode_citation=get_citation_symbol(idx),
            employer=bundle["employer"],
            position=bundle["position"],
            dates=bundle["dates"],
            source_locations=[bundle["source_location"]],
            discovery_state=DiscoveryState.FOUND
        )
        declarations.append(decl)

    return declarations, DiscoveryState.FOUND


def discover_all_employment(extractions: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Run E discovery on all extracted document payloads."""
    results = {}
    for uid, record in extractions.items():
        decls, status = discover_employment_bundles(record)
        results[uid] = {
            "declarations": [d.model_dump() for d in decls],
            "e_status": status.value
        }
    return results
