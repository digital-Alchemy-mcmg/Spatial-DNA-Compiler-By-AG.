"""
SDNA Evidence Foundry — Step 4: Text Extraction Engine
Faithful extraction across DOCX, PDF, TXT, and MD formats.
Enforces Rule SDNA-HF-001 (Header/Footer Isolation).
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, Any, List

from docx import Document as DocxDocument
from pypdf import PdfReader
from charset_normalizer import from_bytes
from markdown_it import MarkdownIt

from step3_media import reclassify_as_media


def extract_docx(filepath: Path) -> Dict[str, Any]:
    """Extract text from DOCX — body, tables, and headers/footers isolated per SDNA-HF-001."""
    doc = DocxDocument(str(filepath))

    body_paragraphs = []
    for i, para in enumerate(doc.paragraphs):
        text_clean = para.text.strip()
        if text_clean:
            body_paragraphs.append({
                "index": i,
                "text": text_clean,
                "style": para.style.name if para.style else None,
                "is_heading": para.style.name.startswith("Heading") if para.style else False,
                "bold_runs": [run.text for run in para.runs if run.bold]
            })

    table_data = []
    for t_idx, table in enumerate(doc.tables):
        for r_idx, row in enumerate(table.rows):
            for c_idx, cell in enumerate(row.cells):
                cell_text = cell.text.strip()
                if cell_text:
                    table_data.append({
                        "table": t_idx,
                        "row": r_idx,
                        "col": c_idx,
                        "text": cell_text
                    })

    # Rule SDNA-HF-001: Header/Footer isolation
    header_footer_text = []
    for section in doc.sections:
        if section.header and section.header.paragraphs:
            for p in section.header.paragraphs:
                p_text = p.text.strip()
                if p_text:
                    header_footer_text.append({"region": "header", "text": p_text})
        if section.footer and section.footer.paragraphs:
            for p in section.footer.paragraphs:
                p_text = p.text.strip()
                if p_text:
                    header_footer_text.append({"region": "footer", "text": p_text})

    body_text = "\n".join(p["text"] for p in body_paragraphs)
    return {
        "body_text": body_text,
        "body_paragraphs": body_paragraphs,
        "table_data": table_data,
        "header_footer_text": header_footer_text,
        "extraction_status": "complete" if body_text else "empty"
    }


def extract_pdf(filepath: Path) -> Dict[str, Any]:
    """Extract text from PDF per-page. Identifies unreadable/scanned PDFs."""
    reader = PdfReader(str(filepath))
    pages = []
    readable_pages = 0

    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        is_readable = bool(text.strip())
        pages.append({
            "page_number": i + 1,
            "text": text.strip(),
            "is_readable": is_readable
        })
        if is_readable:
            readable_pages += 1

    total_pages = len(reader.pages)
    body_text = "\n\n".join(p["text"] for p in pages if p["is_readable"])

    if readable_pages == 0:
        status = "unreadable"
    elif readable_pages < total_pages:
        status = "partial"
    else:
        status = "complete"

    return {
        "body_text": body_text,
        "pages": pages,
        "header_footer_text": [],
        "extraction_status": status,
        "readable_pages": readable_pages,
        "total_pages": total_pages
    }


def extract_txt(filepath: Path) -> Dict[str, Any]:
    """Extract text from plain text file using charset-normalizer encoding detection."""
    raw_bytes = filepath.read_bytes()
    detection = from_bytes(raw_bytes).best()

    if detection is None:
        return {
            "body_text": "",
            "extraction_status": "encoding_failed",
            "header_footer_text": [],
            "lines": []
        }

    text = str(detection)
    lines = text.splitlines()

    return {
        "body_text": text,
        "lines": [{"line_number": i + 1, "text": line} for i, line in enumerate(lines) if line.strip()],
        "header_footer_text": [],
        "extraction_status": "complete" if text.strip() else "empty",
        "detected_encoding": detection.encoding
    }


def extract_markdown(filepath: Path) -> Dict[str, Any]:
    """Extract structured content from Markdown using markdown-it-py."""
    raw_text = filepath.read_text(encoding="utf-8")
    md = MarkdownIt()
    tokens = md.parse(raw_text)

    structured = []
    for token in tokens:
        if token.type in ("heading_open", "paragraph_open", "bullet_list_open"):
            structured.append({
                "type": token.type,
                "tag": token.tag,
                "content": token.content if token.content else None,
                "markup": token.markup
            })
        elif token.type == "inline" and token.content:
            structured.append({
                "type": "text",
                "content": token.content
            })

    return {
        "body_text": raw_text,
        "structured_tokens": structured,
        "header_footer_text": [],
        "extraction_status": "complete" if raw_text.strip() else "empty"
    }


EXTRACTORS = {
    ".docx": extract_docx,
    ".pdf": extract_pdf,
    ".txt": extract_txt,
    ".md": extract_markdown,
}


def extract_all_documents(
    registry: Dict[str, Any],
    media_manifest: List[Dict[str, Any]],
    sources_dir: str | Path = "sources"
) -> Dict[str, Dict[str, Any]]:
    """Run extraction on all accepted documents. Auto-reclassifies unreadable PDFs to media manifest."""
    extractions = {}

    for uid, record in registry.items():
        if record.get("format_class") != "document":
            continue

        ext = record.get("extension", "").lower()
        filepath = Path(record.get("path", ""))
        extractor = EXTRACTORS.get(ext)

        if not extractor:
            extractions[uid] = {
                "source_uid": uid,
                "source_filename": record.get("filename", ""),
                "extraction_status": "no_extractor",
                "body_text": "",
                "header_footer_text": []
            }
            continue

        try:
            result = extractor(filepath)
            result["source_uid"] = uid
            result["source_filename"] = record.get("filename", "")

            # PDF unreadable gate: reclassify as media immediately
            if ext == ".pdf" and result.get("extraction_status") == "unreadable":
                reclassify_as_media(uid, registry, media_manifest, "unreadable_pdf", sources_dir=sources_dir)
                continue

            extractions[uid] = result

        except Exception as e:
            extractions[uid] = {
                "source_uid": uid,
                "source_filename": record.get("filename", ""),
                "body_text": "",
                "extraction_status": f"error: {str(e)}",
                "header_footer_text": []
            }

    return extractions
