"""
SDNA Evidence Foundry — Step 3: Supporting Media Detection & Manifest Creation
Catalogs non-textual media (images, video, audio, unreadable PDFs) without machine interpretation.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, List, Any, Optional

from step1_contracts import (
    ACCEPTED_MEDIA,
    MediaManifestEntry,
    ProcessingStatus
)


def detect_media_and_build_manifest(registry: Dict[str, Any], sources_dir: str | Path = "sources") -> List[Dict[str, Any]]:
    """Filter media from registry and create Media Evidence Manifest."""
    manifest = []
    sources_path = Path(sources_dir)
    sources_path.mkdir(parents=True, exist_ok=True)

    for uid, record in registry.items():
        if record.get("format_class") != "media":
            continue

        ext = record.get("extension", "").lower()

        # Categorize media file
        category = "unknown"
        for cat, extensions in ACCEPTED_MEDIA.items():
            if ext in extensions:
                category = cat
                break

        entry = MediaManifestEntry(
            media_id=f"MED-{uid}",
            filename=record.get("filename", ""),
            file_type=ext,
            category=category,
            source_document=None,
            source_location=None,
            checksum=record.get("checksum", ""),
            registration_status=ProcessingStatus.REGISTERED,
            annotation_status=ProcessingStatus.PENDING_USER,
            what_is_this=None,
            what_does_it_represent=None,
            what_does_it_demonstrate=None,
            associated_project=None,
            attribution_issuer=None
        )
        manifest.append(entry.model_dump())

    # Persist manifest
    manifest_path = sources_path / "media_manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    return manifest


def reclassify_as_media(
    uid: str,
    registry: Dict[str, Any],
    manifest: List[Dict[str, Any]],
    reason: str = "unreadable_pdf",
    sources_dir: str | Path = "sources"
) -> List[Dict[str, Any]]:
    """Reclassify a document as media (e.g. unreadable PDF flagged by Step 4)."""
    if uid in registry:
        record = registry[uid]
        record["format_class"] = "media"
        entry = MediaManifestEntry(
            media_id=f"MED-{uid}",
            filename=record.get("filename", ""),
            file_type=record.get("extension", ""),
            category=reason,
            checksum=record.get("checksum", ""),
            registration_status=ProcessingStatus.REGISTERED,
            annotation_status=ProcessingStatus.PENDING_USER
        )
        manifest.append(entry.model_dump())

        # Update persisted files
        sources_path = Path(sources_dir)
        with open(sources_path / "source_registry.json", "w", encoding="utf-8") as f:
            json.dump(registry, f, indent=2)
        with open(sources_path / "media_manifest.json", "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

    return manifest
