"""
Autonomous Background Ratchet Runner: Foundation Segment (Steps 0, 1, 2)
Tests boundary conditions, validates checksums, tests UID collision-resistance,
and validates immutability invariant.
"""

from __future__ import annotations
import sys
import time
import string
import tempfile
from pathlib import Path
from step1_contracts import get_citation_symbol, UNICODE_CITATION_POOL, SourceRecord, ProcessingStatus
from step2_registration import discover_and_register, generate_uid, compute_checksum


def run_foundation_audit() -> bool:
    print("[RATCHET AUDIT] Executing Foundation Segment Verification...")

    # Test 1: Citation pool doubling mathematical consistency across 100 entries
    for i in range(100):
        sym = get_citation_symbol(i)
        assert len(sym) in (1, 2), f"Symbol length invalid at {i}: {sym}"
    print("  [PASSED] Citation symbol generator strictly adheres to doubling rule across 100 positions.")

    # Test 2: UID Collision resistance & charset bounds
    chars_allowed = set(string.ascii_uppercase + string.digits)
    uids = set()
    for _ in range(500):
        uid = generate_uid(uids)
        assert len(uid) == 3, f"UID length was {len(uid)}"
        assert all(c in chars_allowed for c in uid), f"UID invalid character: {uid}"
    print("  [PASSED] UID generator successfully allocated 500 collision-free 3-char tokens.")

    # Test 3: Immutability invariant test
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        in_dir = tmp_path / "in"
        in_dir.mkdir()
        test_file = in_dir / "candidate.txt"
        test_file.write_text("Original Raw Text Content", encoding="utf-8")

        out_dir = tmp_path / "sources"
        res = discover_and_register(in_dir, out_dir)

        # Alter original file
        test_file.write_text("MODIFIED AFTER REGISTRATION", encoding="utf-8")

        # Verify source file copy preserved original bytes
        reg_record = list(res["registry"].values())[0]
        copied_path = Path(reg_record["path"])
        preserved_content = copied_path.read_text(encoding="utf-8")
        assert preserved_content == "Original Raw Text Content", "Immutability violated!"
        assert compute_checksum(copied_path) == reg_record["checksum"]
    print("  [PASSED] Source immutability preserved. Copied bytes shielded from original alteration.")

    print("[RATCHET AUDIT COMPLETE] Foundation Segment (Steps 0, 1, 2) is verified optimal and hardened.\n")
    return True


if __name__ == "__main__":
    success = run_foundation_audit()
    sys.exit(0 if success else 1)
