"""
SDNA Evidence Foundry — Step 12: Workbook Evidence Organization
Generates the structured, query-friendly XLSX evidence workbook via openpyxl.
Contains 5 dedicated sheets preserving full provenance chain.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any, List

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


HEADER_FILL = PatternFill(start_color="1A365D", end_color="1A365D", fill_type="solid")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
ROW_FONT = Font(name="Calibri", size=10)
SELF_REPORTED_FILL = PatternFill(start_color="FFF3CD", end_color="FFF3CD", fill_type="solid")
BORDER_THIN = Border(
    left=Side(style='thin', color='D3D3D3'),
    right=Side(style='thin', color='D3D3D3'),
    top=Side(style='thin', color='D3D3D3'),
    bottom=Side(style='thin', color='D3D3D3')
)


def auto_fit_columns(ws):
    """Adjusts column widths based on maximum string lengths."""
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val = str(cell.value or "")
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 65)


def style_header_row(ws, headers: List[str]):
    """Applies professional headers and freeze panes."""
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"


def build_evidence_workbook(
    admitted_registry: Dict[str, Dict[str, Any]],
    twin_registry: Dict[str, Dict[str, Any]],
    source_registry: Dict[str, Dict[str, Any]],
    media_manifest: List[Dict[str, Any]],
    output_path: str | Path = "evidence_workbook.xlsx"
) -> Path:
    """Builds the 5-sheet evidence workbook for downstream consumers (Spark & Reasoner)."""
    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # Remove default blank sheet

    # ── Sheet 1: Evidence by Employment ───────────────────────────
    ws_emp = wb.create_sheet(title="Evidence by Employment")
    style_header_row(ws_emp, [
        "Employer Label", "Employer Name", "Atom UID", "Evidence Content",
        "Source UID", "Twin ID", "Source Location", "Source File"
    ])

    # ── Sheet 2: Evidence by Document ─────────────────────────────
    ws_doc = wb.create_sheet(title="Evidence by Document")
    style_header_row(ws_doc, [
        "Source UID", "Twin ID", "Filename", "Atom UID", "Citation Symbol",
        "Employment Label", "Evidence Content", "Source Location"
    ])

    # ── Sheet 3: Non-Blurb Information ────────────────────────────
    ws_nb = wb.create_sheet(title="Non-Blurb Information")
    style_header_row(ws_nb, [
        "Source UID", "Twin ID", "Bundle Type", "Classification",
        "Source Location", "Content (Intact Bundle)"
    ])

    # ── Sheet 4: Media Inventory ──────────────────────────────────
    ws_med = wb.create_sheet(title="Media Inventory")
    style_header_row(ws_med, [
        "Media ID", "Filename", "Category", "File Type", "Registration Status",
        "Annotation Status", "Source Document", "SHA-256 Checksum"
    ])

    # ── Sheet 5: Admission Registry ───────────────────────────────
    ws_adm = wb.create_sheet(title="Admission Registry")
    style_header_row(ws_adm, [
        "Source UID", "Twin ID", "Admission Status", "Source Checksum",
        "Twin Checksum", "Original Filename"
    ])

    # Populate Sheets 1, 2, 3 from Admitted Twins
    for uid, adm_record in admitted_registry.items():
        if adm_record.get("status") != "ADMITTED":
            continue

        twin = twin_registry.get(uid, {})
        src_rec = source_registry.get(uid, {})
        twin_id = twin.get("twin_id", f"{uid}-000")
        src_filename = src_rec.get("filename", "")

        # Citation map inside this twin
        citation_map = {
            d["unicode_citation"]: d for d in twin.get("employment_declarations", [])
            if "unicode_citation" in d
        }

        # Process Atomic Blurbs
        for blurb in twin.get("atomic_blurbs", []):
            atom_uid = blurb.get("uid", "")
            content = blurb.get("content", "")
            citation = blurb.get("citation", "")
            emp_label = blurb.get("employment_label") or "Uncited"
            src_loc = blurb.get("source_location", "")
            decl = citation_map.get(citation, {})
            emp_name = decl.get("employer") or "Uncited / Missing Declaration"

            # Sheet 1: Evidence by Employment
            row_emp = [
                emp_label, emp_name, atom_uid, content,
                uid, twin_id, src_loc, src_filename
            ]
            ws_emp.append(row_emp)

            # Sheet 2: Evidence by Document
            row_doc = [
                uid, twin_id, src_filename, atom_uid, citation or "None",
                emp_label, content, src_loc
            ]
            ws_doc.append(row_doc)

        # Process Non-Blurb Bundles
        for bundle in twin.get("non_blurb_bundles", []):
            b_type = bundle.get("bundle_type", "")
            b_class = bundle.get("classification", "SELF_REPORTED")
            b_loc = bundle.get("source_location", "")
            b_content = bundle.get("content", "")

            ws_nb.append([uid, twin_id, b_type, b_class, b_loc, b_content])
            # Highlight non-blurb self-reported rows
            current_row = ws_nb.max_row
            for c_idx in range(1, 7):
                ws_nb.cell(row=current_row, column=c_idx).fill = SELF_REPORTED_FILL

    # Populate Sheet 4: Media Inventory
    for m in media_manifest:
        ws_med.append([
            m.get("media_id", ""),
            m.get("filename", ""),
            m.get("category", ""),
            m.get("file_type", ""),
            m.get("registration_status", ""),
            m.get("annotation_status", ""),
            m.get("source_document") or "Standalone",
            m.get("checksum", "")
        ])

    # Populate Sheet 5: Admission Registry
    for uid, adm_record in admitted_registry.items():
        src_rec = source_registry.get(uid, {})
        ws_adm.append([
            uid,
            adm_record.get("twin_id", f"{uid}-000"),
            adm_record.get("status", ""),
            adm_record.get("source_checksum", ""),
            adm_record.get("twin_checksum") or "None",
            src_rec.get("filename", "")
        ])

    # Apply auto-fit and cell borders across all sheets
    for ws in [ws_emp, ws_doc, ws_nb, ws_med, ws_adm]:
        auto_fit_columns(ws)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.font = ROW_FONT
                cell.border = BORDER_THIN

    out_file = Path(output_path)
    wb.save(out_file)
    return out_file
