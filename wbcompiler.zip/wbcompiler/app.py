"""
Standalone Web Application for Document / Statement Analysis Engine
Runs locally on Gradio without external services.
"""

from __future__ import annotations
import json
import gradio as gr
from core_engine import process_resume, format_report_text


def analyze_document(text: str):
    if not text or not text.strip():
        return (
            "⚠️ Please enter or paste document text to process.",
            "[]",
            gr.update(visible=False)
        )
    
    results = process_resume(text)
    report = format_report_text(results)
    json_output = json.dumps(results, indent=2)
    
    return report, json_output, gr.update(value=json_output, visible=True)


def build_app():
    with gr.Blocks(title="Document & Statement Analysis Engine") as demo:
        gr.Markdown(
            """
            # 📄 Deterministic Document & Statement Compiler
            **Local & Deterministic Execution Pipeline**
            - Deterministic section detection & sentence parsing
            - Hardened rule matching (action verbs, function words, digit density)
            - No remote dependencies or external API calls
            """
        )
        
        with gr.Row():
            with gr.Column(scale=5):
                text_input = gr.TextArea(
                    label="Input Document / Resume Text",
                    placeholder="Paste your raw document or resume here...",
                    lines=14
                )
                with gr.Row():
                    process_btn = gr.Button("⚡ Process Document", variant="primary")
                    clear_btn = gr.Button("Clear", variant="secondary")
            
            with gr.Column(scale=6):
                with gr.Tabs():
                    with gr.TabItem("Formatted Output"):
                        output_display = gr.TextArea(
                            label="Analysis Report",
                            lines=18,
                            interactive=False
                        )
                    with gr.TabItem("Structured JSON"):
                        json_display = gr.Code(
                            label="JSON Representation",
                            language="json",
                            interactive=False
                        )
                        download_json = gr.File(label="Download Structured JSON", visible=False)
                        
        process_btn.click(
            fn=analyze_document,
            inputs=[text_input],
            outputs=[output_display, json_display, download_json]
        )
        
        clear_btn.click(
            fn=lambda: ("", "", "", gr.update(visible=False)),
            inputs=[],
            outputs=[text_input, output_display, json_display, download_json]
        )
        
    return demo


if __name__ == "__main__":
    app = build_app()
    app.launch(server_name="127.0.0.1", server_port=7860, inbrowser=False)
