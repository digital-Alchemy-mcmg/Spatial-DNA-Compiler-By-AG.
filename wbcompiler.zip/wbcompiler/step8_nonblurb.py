"""
SDNA Evidence Foundry — Step 8: Non-Blurb Information Extraction
Preserves ancillary résumé material as intact, self-reported bundles distinct from atomic evidence.
Governed by SDNA-EF-005 and SDNA-HF-001.
"""

from __future__ import annotations
import re
from typing import List, Dict, Any, Optional, Tuple

from step1_contracts import NonBlurbBundle

ANCILLARY_HEADINGS = {
    "Skills & Keywords": [
        r"\b(?:skills?|competenc(?:y|ies)|technologies?|tools?|expertise)\b",
        r"\b(?:technical\s+skills?|core\s+competencies|key\s+skills?)\b",
        r"\b(?:programming\s+languages?|certifications?|software)\b"
    ],
    "Executive Summary": [
        r"\b(?:summary|profile|professional\s+summary|about\s+me)\b",
        r"\b(?:executive\s+summary|professional\s+profile|overview)\b"
    ],
    "Career Objective": [
        r"\b(?:objective|career\s+objective|career\s+goal|goal)\b"
    ],
    "Other Self-Description": [
        r"\b(?:interests?|hobbies|volunteer|activities?|affiliations?)\b"
    ]
}

SKILL_LIST_PATTERNS = [
    r"(?:[A-Za-z][A-Za-z0-9\+\#\.]+(?:\s+[A-Za-z][A-Za-z0-9\+\#\.]+){0,3})(?:\s*[\|,•]\s*)",
    r"(?:[A-Za-z][A-Za-z0-9\+\#\.\s]{2,30})(?:\s*[\|,•]\s*){2,}"
]


def looks_like_skill_list(text: str) -> bool:
    """Heuristic detector: evaluates whether text block represents a delimited skills list."""
    for pattern in SKILL_LIST_PATTERNS:
        if re.search(pattern, text):
            pipe_count = text.count("|")
            comma_count = text.count(",")
            bullet_count = text.count("•")
            if pipe_count >= 3 or comma_count >= 4 or bullet_count >= 3:
                return True
    return False


def find_section_boundaries(body_text: str) -> List[Dict[str, Any]]:
    """
    Identify section boundaries by scanning for heading-like lines.
    Returns list of dicts with keys: start, end, heading_line, content.
    """
    lines = body_text.splitlines()
    sections = []
    i = 0

    while i < len(lines):
        line = lines[i].strip()
        if (3 < len(line) < 60
                and not line.endswith(".")
                and not line.endswith(",")
                and (line.istitle() or line.isupper() or re.match(r"^[A-Z][a-z]+(?:\s[A-Z][a-z]+)*$", line))):
            
            j = i + 1
            while j < len(lines):
                next_line = lines[j].strip()
                if (3 < len(next_line) < 60
                        and not next_line.endswith(".")
                        and (next_line.istitle() or next_line.isupper())):
                    break
                j += 1

            section_text = "\n".join(lines[i:j]).strip()
            sections.append({
                "start_line": i,
                "end_line": j,
                "heading_line": line,
                "content": section_text
            })
            i = j
        else:
            i += 1

    return sections


def classify_bundle_type(heading: str, content: str) -> Optional[str]:
    """Classify section into an ancillary category, or return None if not ancillary material."""
    combined = (heading + " " + content[:200]).lower()
    for bundle_type, patterns in ANCILLARY_HEADINGS.items():
        for pattern in patterns:
            if re.search(pattern, combined, re.IGNORECASE):
                return bundle_type

    if looks_like_skill_list(content):
        return "Skills & Keywords"

    return None


def build_consumed_regions(declarations: List[Dict[str, Any]], body_text: str) -> List[Tuple[int, int]]:
    """Build list of (start, end) character offsets consumed by employment attribution."""
    consumed = []
    for i, decl in enumerate(declarations):
        employer = decl.get("employer") or ""
        if not employer:
            continue
        start = body_text.find(employer)
        if start == -1:
            continue
        if i + 1 < len(declarations):
            next_emp = declarations[i + 1].get("employer") or ""
            end = body_text.find(next_emp, start) if next_emp else len(body_text)
            if end == -1:
                end = len(body_text)
        else:
            end = len(body_text)
        consumed.append((start, end))
    return consumed


def is_in_consumed_region(offset: int, consumed_regions: List[Tuple[int, int]]) -> bool:
    """Check if character offset is within a consumed employment region."""
    for start, end in consumed_regions:
        if start <= offset < end:
            return True
    return False


def extract_non_blurb_info(
    extraction_record: Dict[str, Any],
    declarations: List[Dict[str, Any]]
) -> List[NonBlurbBundle]:
    """
    Extract ancillary material from body text not consumed by Steps 6-7.
    Preserves original text intact with classification = SELF_REPORTED.
    """
    source_uid = extraction_record.get("source_uid", "SRC")
    body_text = extraction_record.get("body_text", "")

    consumed = build_consumed_regions(declarations, body_text)
    sections = find_section_boundaries(body_text)

    bundles = []
    for sec in sections:
        sec_offset = body_text.find(sec["heading_line"])
        if is_in_consumed_region(sec_offset, consumed):
            continue

        bundle_type = classify_bundle_type(sec["heading_line"], sec["content"])
        if bundle_type is None:
            continue

        bundle = NonBlurbBundle(
            bundle_type=bundle_type,
            content=sec["content"],
            classification="SELF_REPORTED",
            source_location=f"{source_uid} — section: {sec['heading_line']}"
        )
        bundles.append(bundle)

    return bundles


def extract_all_non_blurbs(
    extractions: Dict[str, Dict[str, Any]],
    employment_data: Dict[str, Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """Extract non-blurb information across all documents."""
    all_non_blurbs = {}
    for uid, record in extractions.items():
        decls = employment_data.get(uid, {}).get("declarations", [])
        bundles = extract_non_blurb_info(record, decls)
        all_non_blurbs[uid] = [b.model_dump() for b in bundles]
    return all_non_blurbs
