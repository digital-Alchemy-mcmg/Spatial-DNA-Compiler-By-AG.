"""
SDNA Evidence Foundry — Step 5: Person (P) Bundle Discovery
Searches extracted body and eligible header/footer contact elements.
Uses deterministic regex and local spaCy NER.
"""

from __future__ import annotations
import re
from typing import Dict, Any, List
import spacy

from step1_contracts import (
    ContactElement,
    PersonBundle,
    DiscoveryState
)

# Load verified local spaCy model
nlp = spacy.load("en_core_web_sm")

# ── Deterministic Contact Detection Regexes ────────────────────
EMAIL_PATTERN = re.compile(
    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
)

PHONE_PATTERN = re.compile(
    r'(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}'
    r'|(?:\+\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}'
)

URL_PATTERN = re.compile(
    r'https?://(?:www\.)?(?:linkedin\.com|github\.com|behance\.net|'
    r'dribbble\.com|stackoverflow\.com|medium\.com)[/\w\-._~:/?#\[\]@!$&\'()*+,;=%]*',
    re.IGNORECASE
)


def discover_person(extraction: Dict[str, Any]) -> PersonBundle:
    """Search extracted text for person contact information."""
    body_text = extraction.get("body_text", "")
    header_footer = extraction.get("header_footer_text", [])

    # Combine eligible text sources (SDNA-HF-001: only contact info from HF is eligible)
    hf_text = " ".join(item.get("text", "") for item in header_footer)
    combined_text = (body_text + "\n" + hf_text).strip()

    bundle = PersonBundle()

    if not combined_text:
        bundle.overall_status = DiscoveryState.NOT_FOUND
        return bundle

    # 1. Email Detection
    emails = EMAIL_PATTERN.findall(combined_text)
    if emails:
        first_email = emails[0]
        bundle.email = ContactElement(
            value=first_email,
            discovery_state=DiscoveryState.FOUND,
            source_location="body" if EMAIL_PATTERN.search(body_text) else "header_footer"
        )

    # 2. Phone Detection
    phones = PHONE_PATTERN.findall(combined_text)
    if phones:
        first_phone = phones[0].strip()
        bundle.phone = ContactElement(
            value=first_phone,
            discovery_state=DiscoveryState.FOUND,
            source_location="body" if PHONE_PATTERN.search(body_text) else "header_footer"
        )

    # 3. Professional Profile Links
    prof_links = URL_PATTERN.findall(combined_text)
    for link in prof_links:
        bundle.profile_links.append(ContactElement(
            value=link,
            discovery_state=DiscoveryState.FOUND,
            source_location="body" if link in body_text else "header_footer"
        ))

    # 4. Local spaCy NER for Name and Location (capped at 10000 chars for deterministic latency)
    doc = nlp(combined_text[:10000])

    person_entities = [ent.text.strip() for ent in doc.ents if ent.label_ == "PERSON" and ent.text.strip()]
    if person_entities:
        bundle.name = ContactElement(
            value=person_entities[0],
            discovery_state=DiscoveryState.FOUND,
            source_location="body"
        )

    location_entities = [ent.text.strip() for ent in doc.ents if ent.label_ in ("GPE", "LOC") and ent.text.strip()]
    if location_entities:
        bundle.location = ContactElement(
            value=location_entities[0],
            discovery_state=DiscoveryState.FOUND,
            source_location="body"
        )

    # 5. Overall Status: at least 1 element confirmed = FOUND
    found_count = sum([
        1 if bundle.name.discovery_state == DiscoveryState.FOUND else 0,
        1 if bundle.email.discovery_state == DiscoveryState.FOUND else 0,
        1 if bundle.phone.discovery_state == DiscoveryState.FOUND else 0,
        1 if bundle.location.discovery_state == DiscoveryState.FOUND else 0,
        1 if len(bundle.profile_links) > 0 else 0
    ])

    if found_count >= 1:
        bundle.overall_status = DiscoveryState.FOUND
    else:
        bundle.overall_status = DiscoveryState.NOT_FOUND

    return bundle


def discover_all_persons(extractions: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Run P discovery on all extracted document payloads."""
    person_bundles = {}
    for uid, extraction in extractions.items():
        bundle = discover_person(extraction)
        person_bundles[uid] = bundle.model_dump()
    return person_bundles
