"""
Deterministic Document & Resume Statement Compiler Engine
Zero external API calls, fully reproducible, deterministic execution.
"""

from __future__ import annotations
import re
from typing import Dict, List, Any, Optional

import spacy
from spacy.lang.en import English

# Initialize deterministic sentencizer pipeline
nlp = English()
if "sentencizer" not in nlp.pipe_names:
    nlp.add_pipe("sentencizer")

ACTION_VERBS = {
    'expand', 'expanding', 'seek', 'coordinate', 'coordinating', 'leverage', 'leveraging',
    'foster', 'fostering', 'optimize', 'exceed', 'implement', 'implementing', 'lead', 'led',
    'manage', 'managed', 'develop', 'developed', 'create', 'created', 'assist', 'assisted',
    'design', 'designed', 'analyze', 'analyzed', 'drive', 'drove', 'support', 'supported',
    'facilitate', 'facilitated', 'conduct', 'conducted', 'provide', 'provided', 'oversee',
    'oversaw', 'spearhead', 'spearheaded', 'orchestrate', 'orchestrated', 'ensure', 'ensured',
    'research', 'researching', 'catalog', 'cataloging', 'mentor', 'mentoring', 'sustain',
    'sustaining', 'source', 'sourcing', 'manufacture', 'manufacturing', 'deliver', 'delivering',
    'promote', 'promoting', 'offer', 'offering', 'uphold', 'upholding', 'collaborate', 'collaborating'
}

AUXILIARY_VERBS = {
    'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had'
}

FUNCTION_WORDS = {
    'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'with', 
    'by', 'from', 'of', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 
    'have', 'has', 'had', 'will', 'would', 'can', 'could', 'shall', 'should', 
    'may', 'might', 'must', 'over', 'into', 'upon', 'within'
}


def int_to_excel_col(n: int) -> str:
    """Deterministically convert 1-based integer to Excel-style column label (A, B, ..., Z, AA, AB, ...)."""
    result = []
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        result.append(chr(65 + remainder))
    return ''.join(reversed(result))


def is_section_header(line: str) -> bool:
    """Deterministically identifies section headers based on structural characteristics."""
    words = line.split()
    if not words:
        return False
    
    # Header length constraint: 1 to 5 words
    if not (1 <= len(words) <= 5):
        return False
        
    # Headers should not contain numbers
    if any(c.isdigit() for c in line):
        return False
        
    # Headers should not contain commas
    if ',' in line:
        return False
        
    # All caps header (e.g. WORK EXPERIENCE)
    if line.isupper():
        return True
        
    # Title Case header without trailing period (e.g. Professional Summary)
    if line.istitle() and not line.endswith('.'):
        return True
        
    return False


def process_resume(text: str) -> List[Dict[str, Any]]:
    """
    Main deterministic extraction pipeline.
    Parses sections, segments sentences, validates statement criteria, and flags quality attributes.
    """
    if not text:
        return []

    # 1. Split into original lines and group by detected sections
    raw_lines = text.split('\n')
    sections = []
    current_header = "UNNAMED SECTION (Top of Resume)"
    current_lines = []
    
    for line in raw_lines:
        clean_line = line.strip()
        clean_line = re.sub(r'^[•\*\-]\s*', '', clean_line)
        if not clean_line:
            continue
            
        if is_section_header(clean_line):
            if current_lines:
                sections.append((current_header, current_lines))
            current_header = clean_line
            current_lines = []
        else:
            current_lines.append(clean_line)
            
    if current_lines:
        sections.append((current_header, current_lines))
        
    # 2. Process each section and extract statements
    structured_output = []
    global_counter = 1
    
    for section_idx, (header, lines) in enumerate(sections, start=1):
        cleaned_lines = []
        for line in lines:
            if line and line[-1] not in '.!?;:':
                line = line + "."
            cleaned_lines.append(line)
            
        formatted_text = ' '.join(cleaned_lines)
        doc = nlp(formatted_text)
        
        section_entries = []
        for sent in doc.sents:
            line = sent.text.strip()
            if not line or line[-1] not in '.!?':
                continue
                
            words = line.split()
            word_count = len(words)
            
            # Deterministic word count gate
            if word_count < 4 or word_count > 35:
                continue
                
            clean_words = [w.strip('.,!?;:"\'()').lower() for w in words]
            
            # Verb presence validation
            has_verb = any(w in ACTION_VERBS for w in clean_words) or \
                       any(w in AUXILIARY_VERBS for w in clean_words)
            if not has_verb:
                continue
                
            flags = []
            if word_count < 6:
                flags.append("Short")
                
            func_word_count = sum(1 for w in clean_words if w in FUNCTION_WORDS)
            if word_count >= 5 and (func_word_count / word_count) < 0.20:
                flags.append("Awkward phrasing")
                
            digit_count = sum(c.isdigit() for c in line)
            if digit_count > 0 and (digit_count / len(line)) > 0.15:
                flags.append("High digit density")
                
            if line.isupper() and word_count < 10:
                flags.append("All caps")
                
            section_entries.append({
                "id": f"{global_counter:03d}",
                "text": line,
                "flags": flags,
                "metrics": {
                    "word_count": word_count,
                    "digit_ratio": round(digit_count / len(line), 3) if len(line) else 0,
                    "function_word_ratio": round(func_word_count / word_count, 3) if word_count else 0
                }
            })
            global_counter += 1
            
        structured_output.append({
            "letter": int_to_excel_col(section_idx),
            "header": header,
            "entries": section_entries
        })
        
    return structured_output


def format_report_text(results: List[Dict[str, Any]]) -> str:
    """Format structured results into a clean, human-readable text report."""
    total_entries = sum(len(sec["entries"]) for sec in results)
    out = []
    out.append(f"Scanned {len(results)} sections. Found {total_entries} stand-alone statements.\n")
    out.append("=" * 75)
    
    for section in results:
        out.append(f"\nSECTION {section['letter']}: {section['header'].upper()}")
        out.append("-" * 75)
        
        if not section["entries"]:
            out.append("   (No stand-alone statements detected in this section)")
        else:
            for entry in section["entries"]:
                statement = entry["text"]
                flags = entry["flags"]
                entry_id = entry["id"]
                
                if flags:
                    flag_str = " | ".join(flags)
                    out.append(f"   {entry_id}. [{flag_str}] {statement}")
                else:
                    out.append(f"   {entry_id}. {statement}")
                    
    out.append("\n" + "=" * 75)
    return "\n".join(out)
