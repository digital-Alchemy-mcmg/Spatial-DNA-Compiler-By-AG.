"""
SDNA Evidence Foundry — Step 7: Atomic Blurb Construction & Employment Attribution
Segments employment-associated content into atomic blurbs, assigns sequential UIDs and Unicode citations.
Governed by SDNA-DP-003 §8 and SDNA-EF-005.
"""

from __future__ import annotations
import re
import spacy
from typing import List, Dict, Any, Optional

from step1_contracts import AtomicBlurb

nlp = spacy.load("en_core_web_sm")

OUTCOME_MARKERS = [
    r"that\s+(?:reduced|increased|improved|enabled|resulted|led|cut|raised)",
    r"resulting\s+in",
    r"which\s+(?:reduced|increased|led|enabled)",
    r"\bimproving\b",
    r"\breducing\b"
]


def should_keep_together(sentence: str) -> bool:
    """Return True if action+outcome must stay together as one blurb per SDNA-DP-003 §8."""
    for marker in OUTCOME_MARKERS:
        if re.search(marker, sentence, re.IGNORECASE):
            return True
    return False


def split_independent_claims(sentence: str) -> List[str]:
    """
    Split comma-joined independent claims into separate blurbs unless action-outcome marker is present.
    Example: 'Managed 25 employees, reduced labor costs by 12%' -> 2 blurbs.
    """
    if should_keep_together(sentence):
        return [sentence]
    if "," in sentence:
        pattern = r",\s*(?=[A-Z]|\b(?:reduced|managed|led|developed|built|created|supervised|spearheaded|drove)\b)"
        clauses = re.split(pattern, sentence)
        clauses = [c.strip() for c in clauses if len(c.strip()) > 15]
        if len(clauses) > 1:
            return clauses
    return [sentence]


def segment_into_blurbs(text: str) -> List[str]:
    """
    Split a content region into candidate blurb strings:
    1. Split on bullet/numbered-list markers.
    2. Segment each chunk via spaCy sentence boundaries.
    3. Filter out fragments under 15 characters.
    """
    bullet_pattern = re.compile(
        r"^\s*[•–\-\*]\s+|^\s*\d+[\.)\s]\s+",
        re.MULTILINE
    )
    chunks = bullet_pattern.split(text)
    chunks = [c.strip() for c in chunks if c.strip()]
    result = []

    for chunk in chunks:
        if len(chunk) < 15:
            continue
        doc = nlp(chunk)
        sents = [s.text.strip() for s in doc.sents if len(s.text.strip()) > 15]
        result.extend(sents if sents else [chunk])

    return result


def generate_atom_uid(source_uid: str, sequence: int) -> str:
    """Generate sequential atom UID: {source_uid}-{sequence:03d} (e.g. A7B-001)."""
    return f"{source_uid}-{str(sequence).zfill(3)}"


def locate_content_region(
    body_text: str,
    declaration: Dict[str, Any],
    next_declaration: Optional[Dict[str, Any]]
) -> str:
    """Locate the body text content region associated with an employment declaration."""
    employer = declaration.get("employer") or ""
    if not employer:
        return ""
    start = body_text.find(employer)
    if start == -1:
        return ""
    newline_pos = body_text.find("\n", start)
    start = newline_pos if newline_pos != -1 else start + len(employer)

    # If there is a subsequent employment declaration, end at its employer name
    if next_declaration and next_declaration.get("employer"):
        end = body_text.find(next_declaration["employer"], start)
        if end == -1:
            end = len(body_text)
    else:
        end = len(body_text)

    region_raw = body_text[start:end]

    # Stop region if a major subsequent section header (e.g. EDUCATION, SKILLS, CAREER OBJECTIVE) appears
    ancillary_stop_pattern = re.compile(
        r"\n\s*(?:CAREER OBJECTIVE|TECHNICAL SKILLS|EDUCATION|CERTIFICATIONS|INTERESTS|PROJECTS|PUBLICATIONS|AFFILIATIONS)\b",
        re.IGNORECASE
    )
    stop_match = ancillary_stop_pattern.search(region_raw)
    if stop_match:
        region_raw = region_raw[:stop_match.start()]

    return region_raw.strip()


def construct_atomic_blurbs(
    extraction_record: Dict[str, Any],
    declarations: List[Dict[str, Any]]
) -> List[AtomicBlurb]:
    """
    Transform employment content regions into uniquely identified, Unicode-cited atomic blurbs.
    Ensures absolute fidelity: no text alteration, sequential UIDs with no gaps.
    """
    source_uid = extraction_record.get("source_uid", "SRC")
    body_text = extraction_record.get("body_text", "")
    blurbs: List[AtomicBlurb] = []
    sequence = 1

    for i, decl in enumerate(declarations):
        next_decl = declarations[i + 1] if i + 1 < len(declarations) else None
        region = locate_content_region(body_text, decl, next_decl)
        if not region:
            continue

        raw_segments = segment_into_blurbs(region)
        pos_title = (decl.get("position") or "").strip().lower()
        dates_val = (decl.get("dates") or "").strip().lower()

        for segment in raw_segments:
            seg_lower = segment.strip().lower()
            # Do not emit the declaration header itself (position or dates) as an atomic accomplishment blurb
            if (pos_title and seg_lower == pos_title) or (dates_val and seg_lower == dates_val):
                continue
            if pos_title and dates_val and pos_title in seg_lower and dates_val in seg_lower and len(segment) < 80:
                continue

            sub_claims = split_independent_claims(segment)
            for claim in sub_claims:
                claim_clean = claim.strip()
                if not claim_clean or len(claim_clean) < 15:
                    continue

                employer_name = decl.get("employer") or "unknown"
                blurb = AtomicBlurb(
                    uid=generate_atom_uid(source_uid, sequence),
                    content=claim_clean,
                    citation=decl.get("unicode_citation"),
                    employment_label=decl.get("label"),
                    source_location=f"{source_uid} — region of {employer_name}",
                    is_cited=True
                )
                blurbs.append(blurb)
                sequence += 1

    return blurbs


def construct_all_atomic_blurbs(
    extractions: Dict[str, Dict[str, Any]],
    employment_data: Dict[str, Dict[str, Any]]
) -> Dict[str, List[Dict[str, Any]]]:
    """Construct atomic blurbs across all documents."""
    all_blurbs = {}
    for uid, record in extractions.items():
        decls = employment_data.get(uid, {}).get("declarations", [])
        blurbs = construct_atomic_blurbs(record, decls)
        all_blurbs[uid] = [b.model_dump() for b in blurbs]
    return all_blurbs
