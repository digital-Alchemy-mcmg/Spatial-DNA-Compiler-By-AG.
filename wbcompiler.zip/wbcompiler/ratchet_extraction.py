"""
Continuous Ratchet Runner for Document 2 (Extraction: Steps 3, 4, 5)
Stress tests media separation, PDF unreadable fallback, SDNA-HF-001 isolation gate,
and Person Discovery accuracy.
"""

from __future__ import annotations
import sys
import time
import tempfile
from pathlib import Path
from datetime import datetime

from docx import Document as DocxDocument
from pypdf import PdfWriter
from step1_contracts import DiscoveryState, ProcessingStatus
from step2_registration import discover_and_register
from step3_media import detect_media_and_build_manifest
from step4_extraction import extract_all_documents, extract_docx, extract_txt, extract_markdown
from step5_person import discover_person, discover_all_persons

LOG_FILE = Path("ratchet_audit.log")

def log(msg: str):
    timestamp = datetime.now().isoformat()
    entry = f"[{timestamp}] [EXTRACTION RATCHET] {msg}"
    print(entry, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def test_extraction_baseline() -> bool:
    """Rigorous baseline test suite for Steps 3, 4, 5."""
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)
        in_d = p / "input"
        in_d.mkdir()

        # 1. Create DOCX with Header/Footer Isolation testing SDNA-HF-001
        doc = DocxDocument()
        doc.add_paragraph("Body text line for Alex Morgan.")
        sec = doc.sections[0]
        sec.header.paragraphs[0].text = "Header: alex.morgan@test.com"
        sec.footer.paragraphs[0].text = "Footer: Proprietary and Confidential"
        docx_file = in_d / "sample.docx"
        doc.save(str(docx_file))

        # 2. Plain text
        (in_d / "bio.txt").write_text("Contact: (555) 123-4567, https://github.com/alexm", encoding="utf-8")

        # 3. Media file
        (in_d / "photo.png").write_bytes(b"image bytes")

        # Intake & Discovery
        sources_d = p / "sources"
        reg = discover_and_register(in_d, sources_d)
        manifest = detect_media_and_build_manifest(reg["registry"], sources_d)
        extractions = extract_all_documents(reg["registry"], manifest, sources_d)
        persons = discover_all_persons(extractions)

        # Invariant 1: Media Manifest caught photo.png
        assert len(manifest) == 1
        assert manifest[0]["category"] == "image"

        # Invariant 2: DOCX Header/Footer Isolation Rule SDNA-HF-001
        docx_ext = [ext for ext in extractions.values() if ext["source_filename"] == "sample.docx"][0]
        hf_regions = [item["region"] for item in docx_ext["header_footer_text"]]
        assert "header" in hf_regions and "footer" in hf_regions
        assert "Proprietary and Confidential" not in docx_ext["body_text"]

        # Invariant 3: Person Bundle Discovery from Header contact text
        docx_uid = docx_ext["source_uid"]
        p_res = persons[docx_uid]
        assert p_res["overall_status"] == DiscoveryState.FOUND.value
        assert p_res["email"]["value"] == "alex.morgan@test.com"

    return True


def run_extraction_ratchet_loop(iterations: int = 5, delay_seconds: float = 2.0):
    log("Initializing Continuous Ratchet Loop for Document 2 (Extraction Segment)...")
    
    cycle = 1
    while cycle <= iterations:
        log(f"--- Cycle {cycle}/{iterations}: Stress-testing extraction weak points ---")

        # Weak Point 1: Zero-page and blank PDF reclassification
        try:
            with tempfile.TemporaryDirectory() as td:
                tp = Path(td)
                in_d = tp / "in"
                in_d.mkdir()
                
                # Create an unreadable PDF (blank page with no text streams)
                blank_pdf = in_d / "blank_scanned.pdf"
                writer = PdfWriter()
                writer.add_blank_page(width=100, height=100)
                with open(blank_pdf, "wb") as f:
                    writer.write(f)

                sources_d = tp / "sources"
                reg = discover_and_register(in_d, sources_d)
                manifest = detect_media_and_build_manifest(reg["registry"], sources_d)
                assert len(manifest) == 0  # initially classified as doc

                # Extraction router must dynamically reclassify unreadable PDF as media
                extractions = extract_all_documents(reg["registry"], manifest, sources_d)
                assert len(extractions) == 0  # skipped from doc extractions
                assert len(manifest) == 1  # added to manifest
                assert manifest[0]["category"] == "unreadable_pdf"

            log("  [AUDIT] Weak-link probe: Unreadable/scanned PDF safely reclassified to Media Manifest.")
        except Exception as e:
            log(f"  [REGRESSION DETECTED] Unreadable PDF reclassification failed: {e}")
            raise

        # Baseline Verification Gate
        baseline_ok = test_extraction_baseline()
        if baseline_ok:
            log("  [VERIFIED] All extraction & person discovery invariants intact.")
        else:
            log("  [ROLLBACK ALERT] Extraction verification failed!")
            break

        time.sleep(delay_seconds)
        cycle += 1

    log("Document 2 Ratchet loop iteration batch completed successfully.")


if __name__ == "__main__":
    run_extraction_ratchet_loop(iterations=5, delay_seconds=1.5)
