"""
Continuous Ratchet Runner for Document 3 (Discovery & Atomization: Steps 6, 7, 8)
Stress tests employment bundle recognition, action-outcome pair preservation,
sequential UID integrity without gaps, and non-blurb consumed-region exclusions.
"""

from __future__ import annotations
import sys
import time
from pathlib import Path
from datetime import datetime

from step1_contracts import DiscoveryState
from step6_employment import discover_employment_bundles
from step7_atomization import construct_atomic_blurbs, should_keep_together, split_independent_claims
from step8_nonblurb import extract_non_blurb_info, is_in_consumed_region, build_consumed_regions

LOG_FILE = Path("ratchet_audit.log")

def log(msg: str):
    timestamp = datetime.now().isoformat()
    entry = f"[{timestamp}] [DISCOVERY & ATOMIZATION RATCHET] {msg}"
    print(entry, flush=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def test_doc3_baseline() -> bool:
    """Rigorous baseline test suite for Steps 6, 7, 8."""
    # 1. Action-Outcome pair preservation
    s1 = "Introduced a new inventory system that reduced stock discrepancies by 30%"
    assert should_keep_together(s1) is True
    claims1 = split_independent_claims(s1)
    assert len(claims1) == 1

    # 2. Independent claim split
    s2 = "Managed 25 employees, reduced labor costs by 12%"
    assert should_keep_together(s2) is False
    claims2 = split_independent_claims(s2)
    assert len(claims2) == 2

    # 3. Full document transformation
    record = {
        "source_uid": "A7B",
        "body_text": """PROFESSIONAL SUMMARY
Dynamic technology leader with extensive background in scalable systems.

SKILLS
Python | Docker | Kubernetes | AWS | Go

EXPERIENCE
Acme Corp
Principal Architect
2020 – 2024
• Architected cloud backbone that increased system throughput by 400%.
• Directed 15 staff engineers, supervised hiring across the department.
""",
        "source_path": "test.txt"
    }

    decls, e_status = discover_employment_bundles(record)
    assert e_status == DiscoveryState.FOUND
    assert len(decls) >= 1

    blurbs = construct_atomic_blurbs(record, [d.model_dump() for d in decls])
    assert len(blurbs) >= 2
    # Verify sequential UIDs with no gaps
    uids = [b.uid for b in blurbs]
    assert uids[0] == "A7B-001"
    assert uids[1] == "A7B-002"

    # Verify non-blurb exclusion
    non_blurbs = extract_non_blurb_info(record, [d.model_dump() for d in decls])
    assert len(non_blurbs) >= 1
    for nb in non_blurbs:
        assert nb.classification == "SELF_REPORTED"
        assert "Architected cloud backbone" not in nb.content

    return True


def run_doc3_ratchet_loop(iterations: int = 5, delay_seconds: float = 1.5):
    log("Initializing Continuous Ratchet Loop for Document 3 (Discovery & Atomization)...")

    cycle = 1
    while cycle <= iterations:
        log(f"--- Cycle {cycle}/{iterations}: Stress-testing atomization invariants ---")

        # Weak Point 1: Ordering invariance (Joanne's Fabrics test from spec)
        layouts = [
            "Joanne's Fabrics / Store Manager / 2018–2021\n• Supervised 10 retail staff.\n",
            "2018–2021 | Store Manager | Joanne's Fabrics\n• Supervised 10 retail staff.\n",
            "Store Manager — Joanne's Fabrics (2018–2021)\n• Supervised 10 retail staff.\n"
        ]
        for idx, text in enumerate(layouts):
            rec = {"source_uid": f"L0{idx}", "body_text": f"EXPERIENCE\n{text}"}
            decls, st = discover_employment_bundles(rec)
            assert st == DiscoveryState.FOUND
            assert len(decls) == 1
            assert decls[0].employer == "Joanne's Fabrics"
        log("  [AUDIT] Weak-link probe: Structural layout ordering invariance verified across 3 distinct formats.")

        # Baseline Verification Gate
        baseline_ok = test_doc3_baseline()
        if baseline_ok:
            log("  [VERIFIED] All Document 3 invariants intact. Baseline locked.")
        else:
            log("  [ROLLBACK ALERT] Verification failed!")
            break

        time.sleep(delay_seconds)
        cycle += 1

    log("Document 3 Ratchet loop iteration batch completed successfully.")


if __name__ == "__main__":
    run_doc3_ratchet_loop(iterations=5, delay_seconds=1.0)
