"""
SDNA Evidence Foundry — Step 11: Paired Admission & Duplicate Detection
Enforces the formal gate between construction and consumption.
Enforces byte-identical duplicate detection and validates the 5 admission conditions.
"""

from __future__ import annotations
import json
import hashlib
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from pydantic import BaseModel


class AdmissionRecord(BaseModel):
    source_uid: str
    twin_id: str
    status: str  # ADMITTED / BLOCKED / DUPLICATE_CONTENT
    source_checksum: str
    twin_checksum: Optional[str] = None
    block_reason: Optional[str] = None
    duplicate_of_uid: Optional[str] = None


def verify_admission_conditions(
    uid: str,
    source_record: Dict[str, Any],
    twin: Dict[str, Any]
) -> Tuple[bool, str]:
    """
    Validates all five conditions required for workbook eligibility:
    1. Source UID exists in registry.
    2. Twin uses the exact same base UID (twin_id = source_uid + '-000').
    3. Twin identifies the exact registered source checksum.
    4. Twin contains a valid CompletionFooter certifying completion from Step 10.
    5. Source and twin are presented in the same paired admission operation.
    """
    if not uid or not source_record:
        return False, "Source UID missing from registry"

    expected_twin_id = f"{uid}-000"
    if twin.get("twin_id") != expected_twin_id:
        return False, f"twin_id {twin.get('twin_id')!r} != expected {expected_twin_id!r}"

    if twin.get("source_checksum") != source_record.get("checksum"):
        return False, f"Twin source_checksum {twin.get('source_checksum')!r} does not match registered checksum {source_record.get('checksum')!r}"

    footer = twin.get("completion_footer")
    if not footer:
        return False, "Missing completion footer — twin not certified by Step 10"

    status_val = footer.get("status", footer.get("completion_status"))
    if status_val not in ("COMPLETE", "ProcessingStatus.COMPLETE"):
        return False, f"Completion status is {status_val!r}, not COMPLETE"

    return True, "All admission conditions satisfied"


def detect_duplicate(
    uid: str,
    incoming_checksum: str,
    admitted_registry: Dict[str, Dict[str, Any]]
) -> Optional[str]:
    """Checks if an already admitted source has the identical SHA-256 checksum."""
    for admitted_uid, record in admitted_registry.items():
        if record.get("source_checksum") == incoming_checksum and admitted_uid != uid:
            return admitted_uid
    return None


def admit_pair(
    uid: str,
    source_record: Dict[str, Any],
    twin: Dict[str, Any],
    admitted_registry: Dict[str, Dict[str, Any]]
) -> AdmissionRecord:
    """Attempts to admit the source+twin pair; generates explicit admission/block/duplicate record."""
    incoming_checksum = source_record["checksum"]

    # 1. Byte-level duplicate detection
    dup_uid = detect_duplicate(uid, incoming_checksum, admitted_registry)
    if dup_uid is not None:
        return AdmissionRecord(
            source_uid=uid,
            twin_id=f"{uid}-000",
            status="DUPLICATE_CONTENT",
            source_checksum=incoming_checksum,
            block_reason=f"Byte-identical to already-admitted source {dup_uid!r}",
            duplicate_of_uid=dup_uid
        )

    # 2. Admission conditions verification
    can_admit, reason = verify_admission_conditions(uid, source_record, twin)
    if not can_admit:
        return AdmissionRecord(
            source_uid=uid,
            twin_id=twin.get("twin_id", f"{uid}-000"),
            status="BLOCKED",
            source_checksum=incoming_checksum,
            block_reason=reason
        )

    # 3. Admitted
    twin_json_bytes = json.dumps(twin, sort_keys=True).encode("utf-8")
    twin_checksum = hashlib.sha256(twin_json_bytes).hexdigest()

    rec = AdmissionRecord(
        source_uid=uid,
        twin_id=twin["twin_id"],
        status="ADMITTED",
        source_checksum=incoming_checksum,
        twin_checksum=twin_checksum
    )
    admitted_registry[uid] = rec.model_dump()
    return rec


def run_paired_admission(
    twin_registry: Dict[str, Dict[str, Any]],
    source_registry: Dict[str, Dict[str, Any]],
    admission_dir: str | Path = "admission"
) -> Dict[str, Any]:
    """Execute paired admission across all constructed twins."""
    adm_path = Path(admission_dir)
    adm_path.mkdir(parents=True, exist_ok=True)
    admitted_registry: Dict[str, Dict[str, Any]] = {}
    all_receipts: List[Dict[str, Any]] = []

    for uid, twin in twin_registry.items():
        src_rec = source_registry.get(uid)
        if not src_rec:
            receipt = AdmissionRecord(
                source_uid=uid,
                twin_id=f"{uid}-000",
                status="BLOCKED",
                source_checksum="",
                block_reason="Source record not found in source registry"
            )
            all_receipts.append(receipt.model_dump())
            continue

        if twin.get("is_quarantined"):
            continue

        receipt = admit_pair(uid, src_rec, twin, admitted_registry)
        all_receipts.append(receipt.model_dump())

    registry_path = adm_path / "admission_registry.json"
    with open(registry_path, "w", encoding="utf-8") as f:
        json.dump(all_receipts, f, indent=2)

    return {
        "admitted_registry": admitted_registry,
        "all_receipts": all_receipts,
        "registry_file": str(registry_path)
    }
